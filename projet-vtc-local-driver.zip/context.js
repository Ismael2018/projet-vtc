import React, { createContext, useState } from 'react';

// Création du contexte
const GeneralContext = createContext();

// Composant fournisseur de contexte
const GeneralContextProvider = ({ children }) => {

  const [UserFullNameContext, setUserFullNameContext] = useState('');
  const [UserLatitudeContext, setUserLatitudeContext] = useState();
  const [UserLongitudeContext, setUserLongitudeContext] = useState();
  const [UserPhoneNumberContext, setUserPhoneNumberContext] = useState('');
  const [UserPhotoContext, setUserPhotoContext] = useState();
  const [UserisAbleToWithdrawContext, setUserisAbleToWithdrawContext] = useState('');
  const [UserPointsContext, setUserPointsContext] = useState();
  const [UserwalletBalanceContext, setUserwalletBalanceContext] = useState(0);
  const [UserIDContext, setUserIDContext] = useState();
  const [UserTransactionsContext, setUserTransactionsContext] = useState({}); //{data:{ "libelle_transaction":"", "montant" : 0, "date":"" , "D/C" : "D"}


  //Insertion du numéro de téléphone utilisateur dans le contexte
  const updateUserPhoneNumberContext = (newData) => {
    setUserPhoneNumberContext(newData);
  };

  //Insertion de l'ID utilisateur dans le contexte
  const updateUserIDContext = (newData) => {
    setUserIDContext(newData);
  };

//Insertion de la photo utilisateur dans le contexte
  const updateUserPhotoContext = (newData) => {
    setUserPhotoContext(newData);
  };

  //Insertion du nom complet utilisateur dans le contexte
  const updateUserFullNameContext = (newData) => {
    setUserFullNameContext(newData);
  };

  //Insertion du statut utilisateur dans le contexte pour vérifier s'il est autorisé à faire les retraits d'argent depuis son WALLET
  const updateUserisAbleToWithdrawContext = (newData) => {
    setUserisAbleToWithdrawContext(newData);
  };

  //Insertion des points utilisateur dans le contexte
  const updateUserPointsContext = (newData) => {
    setUserPointsContext(newData);
  };


  //Insertion du solde WALLET utilisateur dans le contexte
  const updateUserwalletBalanceContext = (newData) => {
    setUserwalletBalanceContext(newData);
  };

//Insertion des transactions utilisateur dans le contexte
  const updateUserTransactionsContext = (newData) => {
    setUserTransactionsContext(newData);
  };

  //Insertion de la lat. utilisateur dans le contexte
  const updateUserLatitudeContext = (newData) => {
    setUserLatitudeContext(newData);
  };

  //Insertion de la long. utilisateur dans le contexte
  const updateUserLongitudeContext = (newData) => {
    setUserLongitudeContext(newData);
  };

  return (
    <GeneralContext.Provider value={{ 
      UserIDContext,
      updateUserIDContext,
      UserPhoneNumberContext, 
      updateUserPhoneNumberContext,
      UserPhotoContext, 
      updateUserPhotoContext,
      UserFullNameContext,
      updateUserFullNameContext,
      UserPointsContext,
      updateUserPointsContext,
      UserisAbleToWithdrawContext,
      updateUserisAbleToWithdrawContext,
      UserTransactionsContext,
      updateUserTransactionsContext,
      UserwalletBalanceContext,
      updateUserwalletBalanceContext,
      UserLatitudeContext,
      updateUserLatitudeContext,
      UserLongitudeContext,
      updateUserLongitudeContext
    }}>
      {children}
    </GeneralContext.Provider>
  );
};

export { GeneralContextProvider, GeneralContext };
