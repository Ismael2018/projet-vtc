const Token = "pk.eyJ1IjoiaXNtYWVsdG9ubmUyMDIzIiwiYSI6ImNsazdmMmpyZDA0dmczcG8xcHFzZHBjcDgifQ.k3E80XcfcIOs53T0LD2pwg";

export default Token;