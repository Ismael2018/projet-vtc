import React from 'react';
import { GeneralContextProvider } from './context';
import StackNavigator from './navigator/StackNavigator';


function App(): JSX.Element {
  
  return (

      <GeneralContextProvider>
        <StackNavigator />
      </GeneralContextProvider>
      
  );
}


export default App;
