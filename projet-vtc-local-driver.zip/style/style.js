import { StyleSheet } from "react-native";
import { Dimensions } from 'react-native'
import { Colors } from "react-native/Libraries/NewAppScreen";

const height = Dimensions.get('screen').height;
const width = Dimensions.get('screen').width;

export default StyleSheet.create({
    
    boxRoundedHeader: {
        width:width+90,
        height:height/3, 
        borderBottomLeftRadius:218,
        borderBottomRightRadius:218,
        backgroundColor:"#aeaeae"

    },headerBtn:{
      flexDirection:"row",
     
    },
    main : {
        flex:1,
        justifyContent:"center"
    },
    centerContent: {
        alignItems: 'center',
        justifyContent:'center'
    }, 

    imageRoundedHeader:{
        flex:1,
         position:'relative',
         borderBottomLeftRadius:218,
         borderBottomRightRadius:218,
    },
    woyoLogo: {
        width:150,
        height:100,
       // marginTop:130
    },
    lockLogo: {
        width:150,
        height:100,
        marginTop:30
    },
    boxMiddleContent:{
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'center',
        marginTop:-35
     
    },
    inputContainer: {
        alignItems: 'center',
        flexDirection: 'row',
        marginTop: 15,
        borderRadius: 30,
        paddingHorizontal: 20,
        height: 55,
        width:width-20,
        backgroundColor:"#f0f0f0",
    },
    inputStyle:{
        paddingHorizontal:10,
        fontSize:15,
        backgroundColor:"#f0f0f0",
        fontFamily:'Poppins-SemiBold',
        width:150,
        color:"#000"
    },
    inputSearch:{
      paddingHorizontal:10,
      fontSize:12,
      backgroundColor:"#f0f0f0",
      fontFamily:'Poppins-Regular',
      width:width-150,
      color:"#000"

  },
  
    boxFooterContent:{
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'center',
        backgroundColor: "#ffffff",
        height:45,
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        backgroundColor: "#ffffff",
        shadowColor: '#000',
        shadowOffset: { width: -2, height: -10 },
        shadowOpacity: 0.5,
        shadowRadius: 10,
        elevation: 10,
   
    },
    HalfMap:{
      width:width,
      height:height/2
    },
    FullMap:{
      width:width,
      height:height
    }
    ,
    buttonHomeContent:{
        width:width/3.2,
        height:85,
        borderRadius:15,
        paddingTop:3,
        marginHorizontal:5,
        alignContent:"center",
        alignItems:"center",
        justifyContent:"center",
        backgroundColor: "#f1f1f1",
        shadowColor: '#000',
        shadowOffset: {width: -2, height: 4},
        shadowOpacity: 0.2,
        shadowRadius: 3,
        elevation: 20,
   
    },

    customizedCard:{
      width:width-20,
      height:230,
      borderRadius:15,
      marginHorizontal:5,
      backgroundColor: "#ffffff",
      shadowColor: '#000',
      marginTop:20,
      shadowOffset: {width: -2, height: 4},
      shadowOpacity: 0.2,
      shadowRadius: 3,
      elevation: 20,
 
  },
  VehicleCard:{
    width:width-20,
    height:90,
    borderRadius:15,
    marginHorizontal:5,
    backgroundColor: "#ffffff",
    shadowColor: '#000',
    marginTop:10,
    shadowOffset: {width: -2, height: 4},
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 20,

}
    ,
    textHomeMiddleContent: {
        fontSize: 11,
        fontFamily: 'Poppins-Regular',
        marginTop:-8,
        color:"#000"

    },
    secondButtonMiddleContent:{
        justifyContent:"center",
        alignItems:"center",
        width:width-20,
        backgroundColor:"#543090",
        height:55,
        borderRadius:40,
        marginTop:35
    },
    greenButton:{
      justifyContent:"center",
      alignItems:"center",
      width:width-20,
      backgroundColor:"#12ed93",
      height:55,
      borderRadius:40,
      marginTop:35
  },
  purpleButton:{
    justifyContent:"center",
    alignItems:"center",
    width:width-20,
    backgroundColor:"#543090",
    height:55,
    borderRadius:40,
    marginTop:35
},
    giftPoints:{
      justifyContent:"center",
      alignItems:"center",
      backgroundColor:"#543090",
      height:55,
      width:150,
      minWidth:150,
      borderRadius:40,
      flexDirection:'row',
      paddingHorizontal:20
  },
    textButtonCmdCourse:{
        fontSize: 14,
        fontFamily: 'Poppins-Regular',
        color : "#ffffff",
        justifyContent:"center",
        alignItems:"center",
        textAlign:"justify"
    },
    textModal:{
        fontSize: 12,
        fontFamily: 'Poppins-Regular',
        color : "#000000",
        justifyContent:"center",
        alignItems:"center",
        alignContent:"center",
        textAlign:"justify"
    },
    title: {
        color: "#000000",
        fontSize: 18,
        fontFamily : 'Poppins-SemiBold',
        marginTop: 60,
        
        
      
      },
    advertisingBanner : {
        width: width-10,
        height: height/5.38,
        borderRadius:30,
        marginTop:25,
        backgroundColor:"#fff"
        
    },
    blocAd:{
      width: width-100,
      height: height/5.38,
      borderRadius:30,
      padding:15,
      backgroundColor:"#12ed93",
      marginLeft:20
    },
    iconFooter:{
        width:25,
        height:25,
        marginHorizontal:width/15
    },
    tinyIcon:{
        width:25,
        height:25,
    },
    header:{
        display:"flex",
        justifyContent:"flex-end",
      },
      close:{
        marginLeft:250,
        marginTop:-20,
        marginBottom:20,
        width:20,
        height:20
      },
      swipedCursor:{
        width:60,
        height:8,
        backgroundColor:"#f1f1f1",
        borderRadius:7,
        marginTop:15

      }, lineSeparator:{
        width:width,
        height:1,
        backgroundColor:"#f1f1f1",
        marginTop:15

      },
      invoicePhoto:{
        borderRadius:80,
        height:68,
        width:68,
        marginTop:30
      },
      invoiceDate:{
        marginTop:25,
        fontFamily:'Poppins-Regular',
        fontSize:11.5
      },
      invoiceText:{
        marginTop:25,
        fontFamily:'Poppins-SemiBold',
        fontSize:15
      }, 
      transaction:{
        marginTop:25,
        fontFamily:'Poppins-Bold',
        fontSize:20,
        color:"#000000"
      },
      rating:{
        marginTop:30
      },
      textEndRide:{
        marginTop:30,
        fontFamily:'Poppins-Bold',
        fontSize:25,
        color: "#543090"
      },
      textHeaderGiftPoints:{
        marginTop:30,
        fontFamily:'Poppins-SemiBold',
        fontSize:20,
        color: "#fff"
      }, 
      textPurpleBold:{
        fontFamily:'Poppins-Bold',
        fontSize:23,
        color: "#543090"
      },
      textWalletHeader:{
        marginTop:30,
        fontFamily:'Poppins-Bold',
        fontSize:15,
        color: "#000000"
      },
      text:{
        marginTop:25,
        fontFamily:'Poppins-Regular',
        fontSize:12,
        color:"#000"
      },
      toggle:{
        width:172, 
        height:43,
        backgroundColor:"#f0f0f0",
        borderRadius:30,
        flexDirection:"row"
      },
      toggleBtn:{
        width :85,
        height:40,
        backgroundColor:"#543090",
        borderRadius:25
      },
      refreshIcon:{
        width:40,
        height:40
      },
      btnCloseModal:{
        margin:20
      },
      Modal:{
        width: width,
        //height:height/2,
        borderRadius:20,
        backgroundColor:"#ffffff",
        zIndex:2,
        position:"absolute",
        bottom:0

        
      },
      HighModal:{
        width: width,
        height:height/1.3,
        borderRadius:20,
        backgroundColor:"#ffffff",
        zIndex:2,
        position:"absolute",
        bottom:0

      },
      HistoryMap:{
        width:width-30,
        height:130,
        marginTop:20,

      },
      ajustLocationButton:{
        zIndex:4,
        position:'absolute',
        bottom:10,
        right:0,
        marginRight:10
      },
      openMenu:{
        zIndex:4,
        position:'absolute',
        bottom:10,
        left:0,
      },
      modal: {
        zIndex:2,
        position:'absolute',
        bottom:0,
        left:0,
        right:0
      },
      centerModal: {
        zIndex:2,
        position:'absolute',
        bottom:height/3,
        left:0,
        right:0,
       
      },
      menuModal: {
       zIndex:2,
       position:"absolute",
       right:-20,
       top:-20
       
      },
      
      modalContent: {
        backgroundColor: 'white',
        padding: 22,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 4,
        borderColor: 'rgba(0, 0, 0, 0.1)',
      }

}
);