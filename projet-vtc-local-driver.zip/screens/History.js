import { View, Text,Dimensions,Image,TouchableOpacity,ScrollView,Linking } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import BottomComponent from '../navigator/BottomComponent';
import StarRating from 'react-native-star-rating-widget';
import Mapbox from '@rnmapbox/maps';
import Token from '../mapBoxToken';
import Modal from 'react-native-modal';


const height = Dimensions.get('screen').height;
const width = Dimensions.get('screen').width;

Mapbox.setWellKnownTileServer('Mapbox');
Mapbox.setAccessToken(Token);

export default function History() {

const navigation = useNavigation();
const [visible, setVisible] = useState(false); //To make Modal visible or not
const coordinateExample = [-3.965914 , 5.303590];

const showHideModal = ()=> {
    setVisible(!visible);
}

const makeACall = (driverPhoneNumber)=>{

    if (Platform.OS === 'android') {
        phoneNumber = `tel:${driverPhoneNumber}`;
      } else {
        phoneNumber = `telprompt:${driverPhoneNumber}`;
      }
  
      Linking.openURL(phoneNumber);

}


    
    return (
        <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
          <ScrollView>
          <View style={[style.centerContent]}>
                      <View>
                            {/*Header*/}
                            <View style={[style.headerBtn,style.centerContent]}>
                              {/**Bouton close */}
                              <View style={{marginTop:30,marginLeft:0}}>
                                <TouchableOpacity style={{width:35}} onPress={()=>{navigation.navigate("Home")}}>
                                    <Image source={require('../assets/closev.png')} style={{width:30,height:30, marginHorizontal:0}} resizeMode='contain'/>
                                </TouchableOpacity>
                                </View>


                                <View >
                                        <Text style={[style.transaction,{color:"#000000",fontSize:18,marginHorizontal:width/4,marginTop:33}]}>Historique</Text>   
                                </View>

                                  
                            
                            </View>

                    </View>

                {/*Cards*/}
                    <View>
                            
                                <TouchableOpacity onPress={()=>{showHideModal()}} style={[style.customizedCard]}> 
                                <View style={[style.centerContent, { flexDirection: 'row',width:width-40}]}>
                                <Text style={[style.title, {fontSize:18,flex: 1,marginTop: -8,marginLeft:20}]}>Ven. 14 Juillet 2023</Text>
                               
                                {/**Bouton close */}
                               <View style={[style.transaction,{textAlign: 'right',marginTop:-8,width:55}]}>
                               
                                        <Image source={require('../assets/business.png')} style={{width:80,height:80}} resizeMode='contain'/>
                                </View>
                                </View>

                                <Text style={[style.text, {marginTop: -20,marginLeft:20}]}>Course annulée</Text>

                                {/**Trajet */}
                                <View style={{flexDirection:'row', marginTop:20,marginLeft:15}}>
                                <Image source={require('../assets/pin.png')} style={{width:20,height:20}} resizeMode='contain'/>
                                <Text style={[style.text, {marginTop:0,marginLeft:0}]}>Départ : Rue S22, Abidjan, Marcory</Text>
                                </View>

                                <View style={{flexDirection:'row', marginTop:20,marginLeft:15}}>
                                <Image source={require('../assets/pin.png')} style={{width:20,height:20}} resizeMode='contain'/>
                                <Text style={[style.text, {marginTop:0,marginLeft:0}]}>Arrivée : Avenue Noguès, Abidjan, Plateau</Text>
                                </View>
                                
                                {/**Catégorie et Tarif */}
                                <View style={{flexDirection:'row'}}>
                                <Text style={[style.title, {flex:1,marginTop:30,marginLeft:20,fontSize:15}]}>ECONOMIQUE</Text>
                                <Text style={[style.textEndRide, {marginTop:20,marginRight:20}]}>0 CFA</Text>
                                </View>
                                
                                </TouchableOpacity>

                    <View style={[{marginTop:20}]}>
                           
                    </View>

                    </View>

                    <View>
                            
                            <TouchableOpacity onPress={()=>{showHideModal()}} style={[style.customizedCard]}> 
                            <View style={[style.centerContent, { flexDirection: 'row',width:width-40}]}>
                            <Text style={[style.title, {fontSize:18,flex: 1,marginTop: -8,marginLeft:20}]}>Mer. 12 Juillet 2023</Text>
                           
                            {/**Bouton close */}
                           <View style={[style.transaction,{textAlign: 'right',marginTop:-8,width:55}]}>
                           
                                    <Image source={require('../assets/business.png')} style={{width:80,height:80}} resizeMode='contain'/>
                            </View>
                            </View>

                            <Text style={[style.text, {marginTop: -20,marginLeft:20}]}>Course commandée</Text>

                            {/**Trajet */}
                            <View style={{flexDirection:'row', marginTop:20,marginLeft:15}}>
                            <Image source={require('../assets/pin.png')} style={{width:20,height:20}} resizeMode='contain'/>
                            <Text style={[style.text, {marginTop:0,marginLeft:0}]}>Départ : Rue S22, Abidjan, Marcory</Text>
                            </View>

                            <View style={{flexDirection:'row', marginTop:20,marginLeft:15}}>
                            <Image source={require('../assets/pin.png')} style={{width:20,height:20}} resizeMode='contain'/>
                            <Text style={[style.text, {marginTop:0,marginLeft:0}]}>Arrivée : Avenue Noguès, Abidjan, Plateau</Text>
                            </View>
                            
                         {/**Catégorie et Tarif */}
                                <View style={{flexDirection:'row'}}>
                                <Text style={[style.title, {flex:1,marginTop:30,marginLeft:20,fontSize:15}]}>PREMIUM</Text>
                                <Text style={[style.textEndRide, {marginTop:20,marginRight:20}]}>1800 CFA</Text>
                                </View>
                            </TouchableOpacity>

                <View style={[{marginTop:20}]}>
                       
                </View>

                    </View>

                    <View>
                            
                            <TouchableOpacity onPress={()=>{showHideModal()}}  style={[style.customizedCard]}> 
                            <View style={[style.centerContent, { flexDirection: 'row',width:width-40}]}>
                            <Text style={[style.title, {fontSize:18,flex: 1,marginTop: -8,marginLeft:20}]}>Lun. 10 Juillet 2023</Text>
                           
                            {/**Bouton close */}
                           <View style={[style.transaction,{textAlign: 'right',marginTop:-8,width:55}]}>
                           
                                    <Image source={require('../assets/business.png')} style={{width:80,height:80}} resizeMode='contain'/>
                            </View>
                            </View>

                            <Text style={[style.text, {marginTop: -20,marginLeft:20}]}>Course commandée</Text>

                            {/**Trajet */}
                            <View style={{flexDirection:'row', marginTop:20,marginLeft:15}}>
                            <Image source={require('../assets/pin.png')} style={{width:20,height:20}} resizeMode='contain'/>
                            <Text style={[style.text, {marginTop:0,marginLeft:0}]}>Départ : Rue S22, Abidjan, Marcory</Text>
                            </View>

                            <View style={{flexDirection:'row', marginTop:20,marginLeft:15}}>
                            <Image source={require('../assets/pin.png')} style={{width:20,height:20}} resizeMode='contain'/>
                            <Text style={[style.text, {marginTop:0,marginLeft:0}]}>Arrivée : Avenue Noguès, Abidjan, Plateau</Text>
                            </View>
                            
                            {/**Catégorie et Tarif */}
                            <View style={{flexDirection:'row'}}>
                                <Text style={[style.title, {flex:1,marginTop:30,marginLeft:20,fontSize:15}]}>BUSINESS</Text>
                                <Text style={[style.textEndRide, {marginTop:20,marginRight:20}]}>2410 CFA</Text>
                            </View>
                            </TouchableOpacity>

                <View style={[{marginTop:25}]}>
                       
                </View>

                    </View>
            </View>

            <Modal   isVisible={visible}
                                animationIn="slideInUp" // Animation d'apparition
                                animationOut="slideOutDown" // Animation de disparition
                                onBackdropPress={showHideModal} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.modal}>
                  
              <View style={style.modalContent}>
              

                <View style={[style.HighModal]}>


                      <TouchableOpacity style={style.btnCloseModal} onPress={()=>{showHideModal()}}>
                          <Image source={require("../assets/close.png")} 
                                style={[style.tinyIcon]}
                                resizeMode='contain' /> 
                      </TouchableOpacity>

                  <View style={[style.centerContent,{marginTop:-20}]}>             

                {/**Map */}        
                  <Mapbox.MapView style={style.HistoryMap}>
                        <Mapbox.Camera zoomLevel={15} 
                                        centerCoordinate={coordinateExample} 
                        />
                        <Mapbox.PointAnnotation id='point'
                                                coordinate={coordinateExample}
                        />

                  </Mapbox.MapView>
                
                {/**Détails course */}

                <View>
                           
                            <View style={[style.centerContent, { flexDirection: 'row',width:width-40}]}>
                            <Text style={[style.title, {fontSize:18,flex: 1,marginTop: -8}]}>Ven. 14 Juillet 2023</Text>
                           
                            {/**Bouton close */}
                           <View style={[style.transaction,{textAlign: 'right',marginTop:-8}]}>
                           
                                    <Image source={require('../assets/business.png')} style={{width:80,height:80}} resizeMode='contain'/>
                            </View>
                            </View>

                            <Text style={[style.text, {marginTop: -20}]}>Course commandée</Text>

                               {/**Infos chauffeur */}
                               <View style={style.centerContent}>
                                <View >
                                    <Image source={{uri:"https://solitude.link/stage/woyo/wp-content/uploads/2023/02/intro1.jpg"}} 
                                        style={[style.invoicePhoto,{width:50,height:50}]}
                                        resizeMode='cover' /> 
                                </View>

                                <View>
                                     {/**Rating */}
                                    <StarRating
                                        rating={5}
                                        starSize={12}
                                        onChange={()=>{}}
                                        style={[style.rating,{marginLeft:5,marginTop:10}]}
                                        color="#12ed93"
                                    />
                                </View>

                                <View style={{marginTop:10}}>
                                <Text style={[style.title,{marginTop:0,fontSize:14}]}>Konan Jean-Luc</Text>
                                <TouchableOpacity onPress={()=>{makeACall('0749793919')}}>
                                  <Text style={[style.title,{marginTop:0,fontSize:14,textDecorationLine:'underline'}]}>+225 0749793919</Text>
                                </TouchableOpacity>
                                
                                </View>

                            </View>

                            

                          
                            {/**Trajet */}
                            <View style={{flexDirection:'row', marginTop:20}}>
                            <Image source={require('../assets/pin.png')} style={{width:20,height:20}} resizeMode='contain'/>
                            <Text style={[style.text, {marginTop:0,marginLeft:0}]}>Départ : Rue S22, Abidjan, Marcory</Text>
                            </View>

                            <View style={{flexDirection:'row', marginTop:20}}>
                            <Image source={require('../assets/pin.png')} style={{width:20,height:20}} resizeMode='contain'/>
                            <Text style={[style.text, {marginTop:0,marginLeft:0}]}>Arrivée : Avenue Noguès, Abidjan, Plateau</Text>
                            </View>

                           
                            
                            {/**Catégorie et Tarif */}
                            <View style={{flexDirection:'row'}}>
                            <Text style={[style.title, {flex:1,marginTop:40,fontSize:15}]}>ECONOMIQUE</Text>
                            <Text style={[style.textEndRide, {marginTop:30,marginRight:20}]}>0 CFA</Text>
                            </View>

                            

                </View>

                      
                
                  </View>

                </View>


              </View>

            </Modal>

          </ScrollView>
            
        <BottomComponent />

        </SafeAreaView>
      
    )
}