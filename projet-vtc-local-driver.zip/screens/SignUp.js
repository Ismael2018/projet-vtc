import { View,Dimensions,Image,Text,TouchableOpacity,TextInput,ToastAndroid,SafeAreaView, ScrollView,Switch } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { Picker } from '@react-native-picker/picker';

const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function SignUp() {

const navigation = useNavigation();

const marques = ['BMW','Hyundai','KIA','Peugeot', 'Suzuki', 'Toyota'];
const modeleBMW = ['e45','e90','Autres'];
const modeleHyundai = ['ix35','i10','Grand i10','Santafe','Elentra','Autres'];
const modeleKIA = ['Pegas','Sorento','Sportage','Autres'];
const modelePeugeot = ['205','305','306','307','406','407','508','3008','5008','Autres'];
const modeleSuzuki = ['Alto','Dzire','Espresso','Grand Vitara','Swift','Vitara','Autres'];
const modeleToyota = ['Starlet','Autres'];
const couleurs = ['Blanc','Bleu','Gris','Jaune','Marron','Noir','Rouge','Vert',]

const [selectedOption, setSelectedOption] = useState(marques[2]);
const [selectedOption_, setSelectedOption_] = useState(modeleKIA[0]);
const [selectedOption__, setSelectedOption__] = useState(couleurs[0]);
const [isWoyoDriver, setisWoyoDriver] = useState(false);

  const handleOptionChange = (itemValue) => {
    setSelectedOption(itemValue);
  };

  const handleOptionChange_ = (itemValue) => {
    setSelectedOption_(itemValue);
  };

  const handleOptionChange__ = (itemValue) => {
    setSelectedOption__(itemValue);
  };


function infoCountry (){

    ToastAndroid.showWithGravityAndOffset(
        'En ce moment, nous sommes uniquement présents en Côte d\'ivoire',
        ToastAndroid.LONG,
        ToastAndroid.BOTTOM,
        25,
        50,
      )
}


const toggleSwitch = () => setisWoyoDriver(previousState => !previousState);
    
    return (
        <SafeAreaView style={{flex:1,backgroundColor:"#ffffff"}}>
            <ScrollView>
                       <View >

                <View >
                            <TouchableOpacity onPress={()=>{navigation.navigate("Home")}}>
                                <View style={{marginTop:30,marginLeft:10}}>
                                    <Image
                                    source={require("../assets/leftav.png")}
                                    //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                    style={{width:25,height:25}} 
                                    resizeMode='contain' /> 
                                </View>
                            </TouchableOpacity>
                </View>
                 
                <View style={style.centerContent}>
                  <Text style={style.text}>S'inscrire en tant que</Text>
                  { !isWoyoDriver && <View style={style.toggle}>
                <TouchableOpacity onPress={()=>{}} style={style.toggleBtn}> 
                    <Text style={[style.text,{marginTop:12,color:"#fff",marginLeft:11,fontSize:10}]}>Particulier</Text> 
                   </TouchableOpacity>
                   <TouchableOpacity onPress={()=>{toggleSwitch()}} style={[style.toggleBtn,{backgroundColor:"#f0f0f0"}]}> 
                    <Text style={[style.text,{marginTop:6,color:"#000",marginLeft:11,fontSize:10}]}>Chauffeur WOYO</Text> 
                   </TouchableOpacity>
                  </View> }

                  { isWoyoDriver && <View style={style.toggle}>
                <TouchableOpacity onPress={()=>{toggleSwitch()}} style={[style.toggleBtn,{backgroundColor:"#f0f0f0"}]}> 
                    <Text style={[style.text,{marginTop:12,color:"#000",marginLeft:11,fontSize:10}]}>Particulier</Text> 
                   </TouchableOpacity>
                   <TouchableOpacity onPress={()=>{}} style={[style.toggleBtn]}> 
                    <Text style={[style.text,{marginTop:6,color:"#fff",marginLeft:11,fontSize:10}]}>Chauffeur WOYO</Text> 
                   </TouchableOpacity>
                  </View> }

                </View>


                    {/*<Text style={[style.textPurpleBold,{color:"#000",fontSize:20, marginTop:20, marginLeft:20}]}>Vos informations</Text>*/}
                    </View>

            <View style={[style.centerContent,{marginTop:50}]}>
                
                {/*<Image source={require("../assets/woyologov_t.png")} 
                style={[style.woyoLogo,{marginTop:0}]}
    resizeMode='contain' /> */}
                
                <Text style={[style.textPurpleBold,{color:"#000",fontSize:20,width:width-50}]}>Vos informations</Text>
                {/** Nom complet */}
                <View style={style.inputContainer}>
    
                        <TextInput style={[style.inputStyle,{width:width-50}]}  
                        placeholder="Nom & prénoms" 
                        placeholderTextColor="gray"
                        />
                        
                </View>
                     
                {/** Numéro de téléphone */}

                <View style={[style.inputContainer,{marginTop:15}]}>
                    
                <TouchableOpacity onPress={()=>{infoCountry()}}>
                <Image source={require("../assets/ivory-coast.png")} 
                    style={style.tinyIcon}
                    /> 
                </TouchableOpacity>
                    
                    <TextInput style={style.inputStyle} 
                    maxLength={10}
                    keyboardType="phone-pad" 
                    placeholder="N° Téléphone" 
                    placeholderTextColor="gray"/>
                    
                 </View>

                 {/** PIN */}
                <View style={style.inputContainer}>
    
                        <TextInput style={[style.inputStyle,{width:width-50,letterSpacing:9}]}  
                        placeholder="créez un PIN pour vos retraits" 
                        placeholderTextColor="gray"
                        maxLength={4}
                        keyboardType='visible-password'
                        />
                        
                </View>


                <View style={{height:50}}></View>

                 <Text style={[style.textPurpleBold,{color:"#000",fontSize:20,width:width-50}]}>Votre véhicule</Text>
                {/** Marque du véhicule */}
                <View style={style.inputContainer}>
                    
                  <Picker style={[style.inputStyle,{width:width-80}]} selectedValue={selectedOption} onValueChange={handleOptionChange}>
                            {marques.map((option, index) => (
                            <Picker.Item key={index} label={option} value={option} />
                            ))}
                 </Picker>
                </View>

                {/** Modèle du véhicule */}
                <View style={{flexDirection:'row'}}>

                    <View style={[style.inputContainer,{width:width/2}]}>
                        
                    <Picker style={[style.inputStyle,{width:width/2.6}]} selectedValue={selectedOption_} onValueChange={handleOptionChange_}>
                                {modeleKIA.map((option, index) => (
                                <Picker.Item key={index} label={option} value={option} />
                                ))}
                    </Picker>
                    </View>

                    <View style={[style.inputContainer,{width:width/2.7,marginHorizontal:10}]}>
                        
                    <TextInput style={[style.inputStyle,{width:width/3.7}]}  
                        placeholder="Année" 
                        placeholderTextColor="gray"
                        maxLength={4}
                        keyboardType='number-pad'
                        />
                    </View>

                </View>
                
                {/** Couleur du véhicule */}
                <View style={style.inputContainer}>
                    
                  <Picker style={[style.inputStyle,{width:width-80}]} selectedValue={selectedOption__} onValueChange={handleOptionChange__}>
                            {couleurs.map((option, index) => (
                            <Picker.Item key={index} label={option} value={option} />
                            ))}
                 </Picker>
                </View>


                 {/** Immatriculation */}
                 <View style={style.inputContainer}>
                    
                    <TextInput style={[style.inputStyle,{width:width-80}]}  
                    placeholder="Immatriculation" 
                    placeholderTextColor="gray"
                    />
                    
                </View>
                
                <View style={{marginTop:10,marginBottom:30}}>
                 <TouchableOpacity onPress={()=>{navigation.navigate("UploadFiles")}} style={[style.secondButtonMiddleContent,{width:width-20} ]}>
                    <Text style={style.textButtonCmdCourse}>Suivant</Text> 
                </TouchableOpacity>
              </View>
             </View>
             </ScrollView>
        </SafeAreaView>
      
    )
}