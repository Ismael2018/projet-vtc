import { View, Text,Dimensions,Image,TouchableOpacity,ScrollView,TextInput } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import BottomComponent from '../navigator/BottomComponent';




const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function SearchDestination() {

const navigation = useNavigation();
const [favourite, setfavourite] = useState(false);


//Ajouter un endroit aux favoris
const addToFavouritePlaces = () => {

    setfavourite(!favourite);

}



    
    return (
        <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
          <ScrollView>
          <View style={[style.centerContent]}>
                      <View>
                            {/*Header*/}
                            <View style={[style.headerBtn,style.centerContent]}>
                              {/**Bouton close */}
                              <View style={{marginTop:30,marginLeft:0}}>
                                <TouchableOpacity style={{width:35}} onPress={()=>{navigation.navigate("OrderRide")}}>
                                    <Image source={require('../assets/leftarrowv.png')} style={{width:30,height:30, marginHorizontal:0}} resizeMode='contain'/>
                                </TouchableOpacity>
                                </View>


                                <View >
                                        <Text style={[style.transaction,{color:"#000000",fontSize:18,marginHorizontal:60,marginTop:33}]}>Votre destination</Text>   
                                </View>

                                 
                            
                            </View>

                    </View>

                    {/** Input recherche */}
                 <View style={[style.inputContainer,{height:45,width:width-30}]}>
                
                    <Image source={require("../assets/search.png")} 
                        style={{width:16,height:16}}
                        /> 
                 
    
                        <TextInput style={style.inputSearch}
                        placeholder="Entrez une destination" 
                        placeholderTextColor="gray" />

                        
                        
                     </View>

                     <TouchableOpacity onPress={()=>{navigation.navigate("PinDestinationOnMap")}} style={[style.greenButton,{width:width-30,height:45,flexDirection:"row",marginTop:18} ]}>
                                  <Text style={[style.textHeaderGiftPoints,{marginTop:0,fontSize:16,flex:1,marginLeft:20}]}>Utiliser la carte ? </Text> 
                                  <View style={{marginRight:25,marginBottom:0}}>
                                  <Image source={require("../assets/right-arrow.png")} 
                                        style={{width:30,height:35}}
                                        resizeMode='contain' /> 
                                  </View>
                                </TouchableOpacity>

                     

                     <View style={[{height:45}]}>
                           
                    </View>
                           
                {/*Saved Places*/}
                    <View>
                            
                                <View style={[style.centerContent, { flexDirection: 'row',width:width-40}]}>
                                
                                <View style={{flex:1}}>
                                   <TouchableOpacity onPress={()=>{navigation.navigate("ConfirmRide")}} >
                                     <Text style={[style.title, {fontSize:15,flex: 1,marginTop: -8}]}>Aéroport Félix Houphouet B.</Text>
                                   </TouchableOpacity>
                                   </View>
                                {/**Bouton close */}
                                <View style={[style.transaction,{textAlign: 'right',marginTop:-8,marginHorizontal:5}]}>
                                                    <TouchableOpacity onPress={()=>{addToFavouritePlaces()}}>
                                                    {!favourite && <Image source={require('../assets/whiteheart.png')} style={style.tinyIcon} resizeMode='contain'/>} 
                                                        {favourite && <Image source={require('../assets/redheart.png')} style={style.tinyIcon} resizeMode='contain'/>} 
                                                    </TouchableOpacity>
                              </View>
                                </View>

                                <TouchableOpacity onPress={()=>{navigation.navigate("ConfirmRide")}} > 
                                 <Text style={[style.text, {marginTop: 0}]}>Abidjan 07 CI, Rue G47</Text>
                                 </TouchableOpacity>


                    </View>

                  

        </View>
          </ScrollView>
            
              <BottomComponent />

        </SafeAreaView>
      
    )
}