import { View, Text,Dimensions,Image,TouchableOpacity } from 'react-native'
import React, { useState, useRef, useContext  } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import Mapbox, { Camera, UserLocation  } from '@rnmapbox/maps';
import Token from '../mapBoxToken';
import { GeneralContext } from '../context';
import Modal from 'react-native-modal';
import Menu from './Menu';



const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

Mapbox.setWellKnownTileServer('Mapbox');
Mapbox.setAccessToken(Token);

export default function OrderRide() {

const navigation = useNavigation();
const [favourite, setfavourite] = useState(false);
const [userLocation, setUserLocation] = useState(null);
const mapRef = useRef(null);
const { UserLatitudeContext,updateUserLatitudeContext } = useContext(GeneralContext);
const { UserLongitudeContext,updateUserLongitudeContext } = useContext(GeneralContext);
const [visible, setVisible] = useState(false); //To make Modal visible or not
const [visibleMenu, setVisibleMenu] = useState(false); //To make Modal visible or not
const camera = useRef(null);


/*useEffect(() => {
    Mapbox.setStyleURL('mapbox://styles/mapbox/streets-v11'); 
  }, []);*/

  const [carCoordinates, setCarCoordinates] = useState([UserLongitudeContext+0.0001, UserLatitudeContext+0.0008]);

  /*useEffect(() => {
    // Mettez à jour les coordonnées de la voiture ici (par exemple, à partir d'une source de données en temps réel)
    // Ici, je vais utiliser un simple exemple pour simuler le mouvement de la voiture.
    const interval = setInterval(() => {
      // Simuler le mouvement en ajoutant un petit décalage aux coordonnées de la voiture
      const newLongitude = carCoordinates[0] + 0.0001;
      const newLatitude = carCoordinates[1] + 0.0001;
      setCarCoordinates([newLongitude, newLatitude]);
    }, 1000); // Mettez à jour les coordonnées toutes les 1 seconde

    return () => clearInterval(interval);
  }, [carCoordinates]);*/
  


  function cameraMoveTo() {


    if (camera.current) {
      console.log('Calling setCamera with new coordinates:', UserLongitudeContext, UserLatitudeContext);
      camera.current.setCamera({
        centerCoordinate: [UserLongitudeContext, UserLatitudeContext],
      });
    } else {
      console.log('Camera ref is null or undefined.');
    }
  }

 

//Ajouter un endroit aux favoris
const addToFavouritePlaces = () => {

    setfavourite(!favourite);

}


const showHideModal = ()=> {
  setVisible(!visible);
}

const showHideModalMenu = ()=> {
  setVisibleMenu(!visibleMenu);
}

  
  
    return (
      <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
        
            <View style={[style.centerContent]}>
                        <View>
                                {/*Header*/}
                                <View style={[{width:width,height:height/2}]}>

                                     <View style={[style.headerBtn,style.centerContent,{zIndex:2,position:'absolute',width:width}]}>

                                                {/**Bouton close */}
                                                <View style={{marginTop:30,marginLeft:0}}>
                                                    <TouchableOpacity style={{width:35}} onPress={()=>{navigation.navigate("Home")}}>
                                                        <Image source={require('../assets/closev.png')} style={{width:30,height:30, marginHorizontal:0}} resizeMode='contain'/>
                                                    </TouchableOpacity>
                                                </View>


                                                <View>
                                                        <Text style={[style.transaction,{color:"#000000",fontSize:18,marginHorizontal:width/3,marginTop:33}]}></Text>   
                                                </View>

                                                <View style={{marginTop:30,marginLeft:20}}>
                                                <TouchableOpacity onPress={()=>{showHideModalMenu()}}>
                                                    <Image source={require('../assets/menuv.png')} style={{width:30,height:30, marginHorizontal:0}} resizeMode='contain'/>
                                                </TouchableOpacity>
                                                </View>  

                                     </View>

                           

                                {/**Map */}        
                            <Mapbox.MapView style={style.HalfMap} ref={mapRef}>

                                    <Mapbox.Camera zoomLevel={15} 
                                                    centerCoordinate={[UserLongitudeContext,UserLatitudeContext]} 
                                                    ref={camera}
                                    />
                                        <Mapbox.PointAnnotation id="point" coordinate={[UserLongitudeContext, UserLatitudeContext]} 
                                        // Utilisez le nom de l'image prédéfinie dans les ressources de Mapbox ou l'URI local de votre image
                                        // Par exemple, pour une image prédéfinie : iconImage="marker-15"
                                        // Pour une image locale : iconImage={require('../assets/pin.png')}
                                        iconImage={require('../assets/pin_tiny.png')}
                                        >
                                            <Mapbox.Callout title="Vous êtes ici" />
                                       
                                        </Mapbox.PointAnnotation>
                                        {/**
                                         * <Mapbox.PointAnnotation
                                            id="car"
                                            coordinate={carCoordinates}
                                            iconImage={require('../../projet-vtc-local/assets/berlinerouge.png')}
                                            >
                                            <Mapbox.Callout title="Vehicle location" />
                                        </Mapbox.PointAnnotation>

                                         */}
                                        
                    
                            </Mapbox.MapView>
                                 {/**Ajust button */}   
                                 <View style={style.ajustLocationButton}>
                                    <TouchableOpacity onPress={()=>{cameraMoveTo()}} style={{marginTop:40,marginLeft:10}}>
                                        <Image   source={require("../assets/ajust.png")}
                                            style={{width:46,height:46}} 
                                            resizeMode='contain' /> 
                                    </TouchableOpacity>
                                        
                                </View>

                                </View>

                                <View style={[style.centerContent,{marginTop:8}]}>

                                    <View style={style.swipedCursor}></View>
                                    
                                    <View style={{flexDirection:'row'}}>
                                      <View style={{flex:1, marginLeft:10}}>
                                        <Text style={[style.invoiceText,{fontSize:18,color:"#000000", marginLeft:7}]}>Où allez vous ? </Text>
                                     </View>
                                     
                                     {/**Plus d'options = Programmer un trajet + Commander une course pour quelqu'un */}
                                    <TouchableOpacity onPress={()=>{showHideModal()}}>
                                      <View style={{marginRight:10,flexDirection:'row'}}>
                                            <View> 
                                                <Image source={require("../assets/more.png")}
                                                style={{width:17,height:17,marginTop:29}} 
                                                resizeMode='contain' /> 
                                            </View>

                                            <View style={{marginHorizontal:5}}>
                                            <Text style={[style.invoiceText,{fontSize:9,color:"#000"}]}> Plus</Text>
                                            <Text style={[style.invoiceText,{fontSize:9,color:"#000",marginTop:-5.5,marginLeft:2}]}>d'options</Text>
                                            </View>
                                         </View>
                                      </TouchableOpacity>
                                    </View>

                                {/** Input recherche */}
                                <View style={[style.inputContainer,{height:47,width:width,marginTop:25}]}>
                                    
                                    <Image source={require("../assets/search.png")} 
                                        style={{width:16,height:16}}
                                        /> 

                                   
                                    <Text style={[style.text,{marginLeft:10,marginTop:0}]} onPress={()=>{navigation.navigate("SearchDestination")}}>Entrez votre destination</Text>
                           
                                </View>

                                <TouchableOpacity onPress={()=>{navigation.navigate("PinDestinationOnMap")}} style={[style.greenButton,{width:width,height:50,flexDirection:"row",marginTop:18} ]}>
                                  <Text style={[style.textHeaderGiftPoints,{marginTop:0,fontSize:16,flex:1,marginLeft:20}]}>Utiliser la carte ? </Text> 
                                  <View style={{marginRight:25,marginBottom:0}}>
                                  <Image source={require("../assets/right-arrow.png")} 
                                        style={{width:30,height:35}}
                                        resizeMode='contain' /> 
                                  </View>
                                </TouchableOpacity>
                                    

                                </View>

                                <View style={[style.main,style.centerContent,{marginTop:-20}]}>
                                   
                                   {/*Saved Places*/}
                                    <View>
                                                <View style={[style.centerContent, { flexDirection: 'row',width:width-40}]}>

                                                    <View style={{flex:1}}>
                                                    <TouchableOpacity onPress={()=>{navigation.navigate("ConfirmRide")}} >
                                                        <Text style={[style.title, {fontSize:15,marginTop:-8}]}>Aéroport Félix Houphouet B.</Text>
                                                    </TouchableOpacity>
                                                    </View>
                                                {/**Bouton close */}
                                                <View style={[style.transaction,{textAlign: 'right',marginTop:-8,marginHorizontal:5}]}>

                                                    <TouchableOpacity onPress={()=>{addToFavouritePlaces()}}>
                                                    {!favourite && <Image source={require('../assets/whiteheart.png')} style={style.tinyIcon} resizeMode='contain'/>} 
                                                        {favourite && <Image source={require('../assets/redheart.png')} style={style.tinyIcon} resizeMode='contain'/>} 
                                                    </TouchableOpacity>
                                                 
                                                </View>
                                                </View>

                                                <TouchableOpacity onPress={()=>{navigation.navigate("ConfirmRide")}} > 
                                                   <Text style={[style.text, {marginTop: 0}]}>Abidjan 07 CI, Rue G47</Text>
                                                </TouchableOpacity>

                                    </View>
                                   
                                </View>

                        </View>

                        <Modal isVisible={visible}
                                animationIn="fadeIn" // Animation d'apparition
                                animationOut="fadeOut" // Animation de disparition
                                onBackdropPress={showHideModal} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.centerModal}>
                        
                         <View style={[style.centerContent]}>
                       

                        <View style={[style.Modal,{height:height/3.7, width:width-30,bottom:0,left:0,right:0}]}>

                            <TouchableOpacity style={style.btnCloseModal} onPress={()=>{showHideModal()}}>
                                <Image source={require("../assets/close.png")} 
                                        style={[style.tinyIcon]}
                                        resizeMode='contain' /> 
                            </TouchableOpacity>

                          <View style={[style.centerContent,{marginTop:-20}]}>   

                          <Image source={require("../assets/woyologov_t.png")} 
                                        style={{width:100,height:38}}
                                        resizeMode='cover' /> 

                            {/**Boutons */}

                            <View style={[style.centerContent,{flexDirection:'row',marginTop:10}]}>

                                <TouchableOpacity onPress={()=>{}} style={[style.purpleButton,{width:150,height:65,marginTop:18,marginHorizontal:5,padding:15,opacity:0.6} ]}>
                                <Text style={[style.textButtonCmdCourse,{marginTop:-3,fontSize:10.5,textAlign:'center'}]}>Commander pour un ami </Text> 
                                </TouchableOpacity>

                                <TouchableOpacity onPress={()=>{showHideModal();navigation.navigate("ScheduleRide")}} style={[style.purpleButton,{width:150,height:65,marginTop:18,marginHorizontal:5,padding:15} ]}>
                                <Text style={[style.textButtonCmdCourse,{marginTop:-3,fontSize:10.5,textAlign:'center'}]}>Programer un trajet </Text> 
                                </TouchableOpacity>
                            </View>
                    
                          </View>

                        </View>


                         </View>

                       </Modal>
            </View>

            <Modal isVisible={visibleMenu}
                                animationIn="slideInRight" // Animation d'apparition
                                animationOut="slideOutRight" // Animation de disparition
                                onBackdropPress={showHideModalMenu} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.menuModal}>
                        
                         <View style={[style.centerContent]}>
                       

                        <View style={[{height:height, width:width-50}]}>
                            
                            <Menu/>
                          
                        </View>


                         </View>

            </Modal>
   
       </SafeAreaView>
      
    )
}