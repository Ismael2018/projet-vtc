import { View, Text,Dimensions,Image,TouchableOpacity,RefreshControl,ToastAndroid,ScrollView,TextInput } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import BottomComponent from '../navigator/BottomComponent';



const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function PayRideWallet() {

const navigation = useNavigation();
const [balance,setbalance] = useState(0);
const [rideAmount,setrideAmount] = useState(3150);
const [refreshing, setRefreshing] = useState(false);
const [phoneNumber, setphoneNumber] = useState("0749793919");


const onRefresh = () => {
    // Mettez à jour l'état de rafraîchissement
    setRefreshing(true);
  
    // Effectuez les actions de rafraîchissement (ex. : récupération de nouvelles données)

    ToastAndroid.showWithGravityAndOffset(
      'Le solde a été mis à jour',
      ToastAndroid.LONG,
      ToastAndroid.BOTTOM,
      25,
      50,
    );
    // Mettez à jour l'état de rafraîchissement après avoir terminé les actions de rafraîchissement
    setRefreshing(false);
  };


  function infoCountry (){

    ToastAndroid.showWithGravityAndOffset(
        'En ce moment, nous sommes uniquement présents en Côte d\'ivoire',
        ToastAndroid.LONG,
        ToastAndroid.BOTTOM,
        25,
        50,
      )
}

    
    return (
      <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
        <ScrollView refreshControl={
            <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            />
        } > 
        
            <View style={[style.centerContent]}>
                        <View>
                                {/*Header*/}
                                <View style={[{backgroundColor:"#ddd5ea",width:width,height:height/2.5}]}>

                                {/**Bouton close 
                                <View style={{marginTop:30,marginLeft:20}}>
                                <TouchableOpacity style={{width:35}} onPress={()=>{navigation.navigate("Wallet")}}>
                                    <Image source={require('../assets/close.png')} style={style.tinyIcon} />
                                </TouchableOpacity>
                                </View>*/}
                                    
                                <View style={style.centerContent}>
                                    <Image source={require("../assets/refresh.png")} 
                                        style={[style.refreshIcon,{marginTop:30}]}
                                        resizeMode='contain' /> 
                                    <Text style={style.text}>Solde actuel</Text>

                                    {/**solde en CFA */}
                                    <View style={[style.centerContent,{marginTop:20,height:80,backgroundColor:"#ffffff",borderRadius:50,minWidth:180,padding:10,paddingLeft:20,paddingRight:20}]}>
                                        
                                    <Text style={[style.invoiceText,{fontSize:35,color:"#000000",marginTop:0,fontFamily:"Poppins-Bold"}]}>
                                    {balance} CFA</Text>
                                
                                    </View>

                                  
                                    <View style={{flexDirection:'row',display:'flex',marginTop:30}}> 
                                        <Text style={[style.textWalletHeader,{marginTop:0}]}>Mon </Text> 
                                        <Text style={{margin:5, marginTop:-20 }}><Image source={require('../assets/woyologov.png')} style={[{width:70,height:35}]} resizeMode='contain' /></Text>
                                        <Text style={[style.textWalletHeader,{marginTop:0}]}>Wallet </Text> 
                                    </View> 
                                  


                                </View>

                                </View>

                                <View style={[style.centerContent,{marginTop:30}]}>
                                    <Text style={[style.invoiceText,{fontSize:20,color:"#000000"}]}>Saisissez les informations </Text>
                                    <Text style={[style.invoiceText,{fontSize:20,color:"#000000",marginTop:0}]}>de la transaction </Text>
                                </View>

                                <View style={[style.main,style.centerContent]}>
                                   
                                    {/** Numéro de téléphone */}
                                    <View style={style.inputContainer}>
                                        
                                        <TouchableOpacity onPress={()=>{infoCountry()}}>
                                        <Image source={require("../assets/ivory-coast.png")} 
                                            style={style.tinyIcon}
                                            /> 
                                        </TouchableOpacity>
                        
                                            <TextInput style={style.inputStyle} 
                                            maxLength={10}
                                            keyboardType="phone-pad" 
                                            placeholder="N° Téléphone"
                                            value={phoneNumber}
                                            onChangeText={newText => {setphoneNumber(newText)}} 
                                            placeholderTextColor="gray"
                                            />
                                            
                                    </View>

                                    {/** Tarif de la course */}
                                   
                                    <View style={[style.centerContent]}>
                                        <Text style={[style.textEndRide,{fontSize:20}]}>Tarif de la course : {rideAmount} CFA</Text>
                                    </View>


                                    <TouchableOpacity onPress={()=>{ navigation.navigate("EndRide") }} style={[style.secondButtonMiddleContent,{width:width-150,marginTop:20} ]}>
                                        <Text style={style.textButtonCmdCourse}>Valider</Text> 
                                    </TouchableOpacity>

                                </View>

                        </View>
            </View>
        
         </ScrollView>

          {/*Footer*/}
          <View style={style.boxFooterContent}>
              <BottomComponent/>
             </View>
       </SafeAreaView>
      
    )
}