import { View, Text,Dimensions,Image,TouchableOpacity,ScrollView,TextInput,ToastAndroid,RefreshControl,Linking } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import BottomComponent from '../navigator/BottomComponent';
import ImageCropPicker from 'react-native-image-crop-picker';
import Modal from 'react-native-modal';
import {LineChart} from "react-native-chart-kit";




const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function Gains() {

const navigation = useNavigation();

const [refreshing, setRefreshing] = useState(false); //Mise à jour de la photo de profil
const [imageUri, setImageUri] = useState(null); // Browse Photo from gallery
const [visible, setVisible] = useState(false); //To make Modal visible or not

const [fullName, setfullName] = useState("Ismaël Tonné");
const [phoneNumber, setphoneNumber] = useState("0749793919");
const [emergencyPhoneNumber, setemergencyPhoneNumber] = useState("0505192955");

var dayFr;
var dayInNumberFr;
var monthFr;
var yearFr;


  //Jour
  switch (new Date().getDay()) {
    case 0:
      dayFr = "Dimanche";
      break;
    case 1:
      dayFr = "Lundi";
      break;
    case 2:
       dayFr = "Mardi";
      break;
    case 3:
      dayFr = "Mercredi";
      break;
    case 4:
      dayFr = "Jeudi";
      break;
    case 5:
      dayFr = "Vendredi";
      break;
    case 6:
      dayFr = "Samedi";
  }


  //Mois
  switch (new Date().getMonth()+1) {
 
    case 1:
      monthFr = "Janvier";
      break;
    case 2:
       monthFr = "Février";
      break;
    case 3:
      monthFr = "Mars";
      break;
    case 4:
      monthFr = "Avril";
      break;
    case 5:
      monthFr = "Mai";
      break;
    case 6:
      monthFr = "Juin";
      break;
    case 7:
      monthFr = "Juillet";
      break;
    case 8:
      monthFr = "Août";
      break;
    case 9:
      monthFr = "Septembre";
      break;
    case 10:
      monthFr = "Octobre";
      break;
    case 11:
      monthFr = "Novembre";
      break;
    case 12:
      monthFr = "Décembre";
  }

  dayInNumberFr= new Date().getDate();
  yearFr = new Date().getFullYear();




  function infoCountry (){

    ToastAndroid.showWithGravityAndOffset(
        'En ce moment, nous sommes uniquement présents en Côte d\'ivoire',
        ToastAndroid.LONG,
        ToastAndroid.BOTTOM,
        25,
        50,
      )
}


const onRefresh = () => {
    // Mettez à jour l'état de rafraîchissement
    setRefreshing(true);
  
    // Effectuez les actions de rafraîchissement (ex. : récupération de nouvelles données)

    ToastAndroid.showWithGravityAndOffset(
      'Mise à jour effectuée',
      ToastAndroid.LONG,
      ToastAndroid.BOTTOM,
      25,
      50,
    );
    // Mettez à jour l'état de rafraîchissement après avoir terminé les actions de rafraîchissement
    setRefreshing(false);
  };


const showHideModal = ()=> {
    setVisible(!visible);
}


return (
    <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
          
      
          <View style={[style.centerContent,{flex:1}]}>
                      <View>
                              {/*Header*/}
                              <View style={[style.VehicleCard,{width:width,height:height/3.8,marginTop:0,borderBottomRightRadius:40,borderBottomLeftRadius:40}]}>
                                        
                                        {/**Bouton close */}
                                <View style={{marginLeft:20,marginTop:15,zIndex:2,position:'absolute'}}>
                                <TouchableOpacity style={{width:35}} onPress={()=>{navigation.navigate("Home")}}>
                                    <Image source={require('../assets/close.png')} style={style.tinyIcon} resizeMode='contain'/>
                                </TouchableOpacity>
                                </View>


                              <View style={style.centerContent}>
                                  {/*<Image source={require("../assets/refresh.png")} 
                                      style={[style.refreshIcon,{marginTop:10}]}
                                      resizeMode='contain' /> */}
                                
                                

                              <View style={{marginTop:20,flexDirection:"row"}}>
                              <TouchableOpacity onPress={()=>{}} style={[style.secondButtonMiddleContent,{width:100,marginHorizontal:5,backgroundColor:"#12ed93"} ]}>
                                    <Text style={[style.textButtonCmdCourse,{fontSize:10}]}>Aujourd'hui</Text> 
                                </TouchableOpacity>

                                <TouchableOpacity onPress={()=>{}} style={[style.secondButtonMiddleContent,{width:100,marginHorizontal:5,opacity:0.5} ]}>
                                    <Text style={[style.textButtonCmdCourse,{fontSize:10}]}>Cette semaine</Text> 
                                </TouchableOpacity>

                                <TouchableOpacity onPress={()=>{}} style={[style.secondButtonMiddleContent,{width:100,marginHorizontal:5,opacity:0.5} ]}>
                                    <Text style={[style.textButtonCmdCourse,{fontSize:10}]}>Ce mois</Text> 
                                </TouchableOpacity>
                              </View>

                                
                                  <View style={{marginTop:20}}> 
                                      <Text style={[style.textHeaderGiftPoints,{marginTop:0,color:"#543090",fontSize:30}]}>0 CFA</Text> 
                                  </View> 

                                

                              </View>

                              </View>

    

                          <View style={{flex:1}}>
                          
                              <View style={[{marginTop:0,marginLeft:20,flexDirection:"row"}]}>
                                  <Text style={[style.invoiceText,{fontSize:18,color:"#000"}]}>Votre activité</Text>
                                  <Text style={{marginTop:23}}> <Image source={require('../assets/flash.png')} style={{width:23,height:23}} resizeMode='contain'/> </Text>
                                  
                              </View>

                              {/** Chart */}
                              <View style={style.centerContent}>
                              <LineChart
                                    data={{
                                      labels: ["00:00", "06:00", "08:00", "15:00", "20:00", "23:00"],
                                      datasets: [
                                        {
                                          data: [
                                            Math.random() * 10,
                                            Math.random() * 10,
                                            Math.random() * 10,
                                            Math.random() * 10,
                                            Math.random() * 10,
                                            Math.random() * 10
                                          ]
                                        }
                                      ]
                                    }}
                                    width={width-20} 
                                    height={height/4}
                                    yAxisLabel="CFA"
                                    yAxisSuffix="k"
                                    yAxisInterval={1} // optional, defaults to 1
                                    chartConfig={{
                                      backgroundColor: "#fff",
                                      backgroundGradientFrom: "#12ed93",
                                      backgroundGradientTo: "#543090",
                                      decimalPlaces: 2, // optional, defaults to 2dp
                                      color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
                                      labelColor: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
                                      style: {
                                        borderRadius: 16
                                      },
                                      propsForDots: {
                                        r: "6",
                                        strokeWidth: "2",
                                        stroke: "#543090",
                                      }
                                    }}
                                    bezier
                                    style={{
                                      marginVertical: 8,
                                      borderRadius: 16
                                    }}
                                  />

                              </View>
              
                              <View style={[{marginTop:0,marginLeft:20,flexDirection:"row"}]}>
                                  <Text style={[style.invoiceText,{fontSize:18,color:"#000"}]}>Commandes</Text>
                                  <Text style={{marginTop:23}}> <Image source={require('../assets/flash.png')} style={{width:23,height:23}} resizeMode='contain'/> </Text>
                                  
                              </View>

                              {/** Chart */}
                              <View style={style.centerContent}>
                              <LineChart
                                    data={{
                                      labels: ["00:00", "06:00", "08:00", "15:00", "20:00", "23:00"],
                                      datasets: [
                                        {
                                          data: [
                                            parseInt(Math.random() * 10),
                                            parseInt(Math.random() * 10),
                                            parseInt(Math.random() * 10),
                                            parseInt(Math.random() * 10),
                                            parseInt(Math.random() * 10),
                                            parseInt(Math.random() * 10)
                                          ]
                                        }
                                      ]
                                    }}
                                    width={width-20} 
                                    height={height/4}
                                    yAxisLabel=""
                                    yAxisSuffix=""
                                    yAxisInterval={1} // optional, defaults to 1
                                    chartConfig={{
                                      backgroundColor: "#fff",
                                      backgroundGradientFrom: "#12ed93",
                                      backgroundGradientTo: "#543090",
                                      decimalPlaces: 2, // optional, defaults to 2dp
                                      color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
                                      labelColor: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
                                      style: {
                                        borderRadius: 16
                                      },
                                      propsForDots: {
                                        r: "6",
                                        strokeWidth: "2",
                                        stroke: "#543090",
                                      }
                                    }}
                                    bezier
                                    style={{
                                      marginVertical: 8,
                                      borderRadius: 16
                                    }}
                                  />

                              </View>
              
                             
                          </View>
                      </View>
          </View>

         {/* <Modal isVisible={visible}
                                animationIn="slideInUp" // Animation d'apparition
                                animationOut="slideOutDown" // Animation de disparition
                                onBackdropPress={showHideModal} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.modal}>
                  
              <View style={style.modalContent}>
               

                <View style={[style.Modal,{height:height/2.5}]}>


                      <TouchableOpacity style={style.btnCloseModal} onPress={()=>{showHideModal()}}>
                          <Image source={require("../assets/close.png")} 
                                style={[style.tinyIcon]}
                                resizeMode='contain' /> 
                      </TouchableOpacity>

                  <View style={[style.centerContent]}>             
                                {/** Nom complet 
                          <View style={style.inputContainer}>
              
                                  <TextInput style={[style.inputStyle,{width:width-100,fontSize:13}]}  
                                  placeholder="Nom & prénoms" 
                                  onChangeText={newText => setfullName(newText)}/>
                                  
                          </View>
                        
                          <View style={[style.inputContainer,{marginTop:10}]}>
                              
                          <TouchableOpacity onPress={()=>{infoCountry()}}>
                          <Image source={require("../assets/ivory-coast.png")} 
                              style={style.tinyIcon}
                              /> 
                          </TouchableOpacity>
                              
                              <TextInput style={[style.inputStyle,{fontSize:13,width:width-80}]} 
                              maxLength={10}
                              keyboardType="phone-pad" 
                              placeholder="Modifier votre N° Téléphone"
                              onChangeText={newText => setphoneNumber(newText)}
                              placeholderTextColor="gray" />
                              
                          </View>

                        
                          <View style={[style.inputContainer,{marginTop:10}]}>
                              
                          <TouchableOpacity onPress={()=>{infoCountry()}}>
                          <Image source={require("../assets/ivory-coast.png")} 
                              style={style.tinyIcon}
                              /> 
                          </TouchableOpacity>
                              
                              <TextInput style={[style.inputStyle,{width:width-100,fontSize:13}]} 
                              maxLength={10}
                              keyboardType="phone-pad" 
                              placeholder="Contact d'urgence" 
                              onChangeText={newText => setemergencyPhoneNumber(newText)} 
                              placeholderTextColor="gray"/>
                              
                          </View>

                          <TouchableOpacity onPress={()=>{showHideModal()}} style={[style.secondButtonMiddleContent,{width:width-20,marginTop:15} ]}>
                            <Text style={[style.textButtonCmdCourse]}>Enregistrer les modifications</Text> 
                         </TouchableOpacity>
                
                  </View>

                </View>


              </View>

            </Modal> */}
      

     </SafeAreaView>
    
  )
}