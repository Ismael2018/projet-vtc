import React from 'react';
import MapboxGL from '@rnmapbox/maps';

const UserLocationMarker = ({ coordinates }) => {
  return (
    <MapboxGL.SymbolLayer
      id="userLocationMarker"
      style={{
        iconImage: 'user_location_icon', // Assurez-vous que le nom correspond au nom de votre icône personnalisée dans les ressources.
        iconAllowOverlap: true,
        iconSize: 0.8,
      }}
    >
      <MapboxGL.PointAnnotation id="userLocation" coordinate={coordinates} />
    </MapboxGL.SymbolLayer>
  );
};

export default UserLocationMarker;
