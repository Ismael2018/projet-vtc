import { View,Dimensions,Image,Text,TouchableOpacity,TextInput,ToastAndroid,SafeAreaView } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';


const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function OTP() {

const navigation = useNavigation();
const [OTPentered, setOTPentered] = useState('')

function verifyOTP(){
    console.log(OTPentered)
    if(OTPentered=="4444"){
        navigation.navigate("Home");
    }
}
    
    return (
        <SafeAreaView style={{backgroundColor:"#ffffff",height:height}}>
            <View style={[style.centerContent]}>

                <Image source={require("../assets/woyologov_t.png")} 
                style={[style.woyoLogo,{marginTop:50}]}
                resizeMode='contain' /> 
                
                <Image source={require("../assets/password.gif")} 
                style={style.lockLogo}
                resizeMode='contain' /> 

                <View style={[style.centerContent]}>
                <Text style={[style.title]}>Entrez le code de validation</Text> 
                <Text style={[style.title,{marginTop:0}]}>envoyé par SMS</Text>  
                </View>

                 <View style={[style.inputContainer,{width:width-200,justifyContent:'center',alignItems:'center'}]}>       

                    <TextInput style={[style.inputStyle,{width:width-250,fontSize:20,letterSpacing:9}]} 
                    maxLength={4}
                    keyboardType="phone-pad" 
                    placeholder=""
                    onChangeText={newText => {setOTPentered(newText)}} 
                    placeholderTextColor="gray"
                    />
                    
                 </View>

                 <TouchableOpacity onPress={()=>{verifyOTP()}} style={[style.secondButtonMiddleContent,{width:width-200} ]}>
                    <Text style={style.textButtonCmdCourse}>Vérifier</Text> 
                </TouchableOpacity>
                
             </View>
        </SafeAreaView>
      
    )
}