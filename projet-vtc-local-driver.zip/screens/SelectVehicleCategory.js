import { View, Text,Dimensions,Image,TouchableOpacity,ToastAndroid,TextInput } from 'react-native'
import React, { useState, useRef, useContext, useEffect  } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import Mapbox, { Camera, UserLocation  } from '@rnmapbox/maps';
import Token from '../mapBoxToken';
import { GeneralContext } from '../context';
import Modal from 'react-native-modal';
import Menu from './Menu';




const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

Mapbox.setWellKnownTileServer('Mapbox');
Mapbox.setAccessToken(Token);

export default function SelectVehicleCategory() {

const navigation = useNavigation();
const [favourite, setfavourite] = useState(false);
const [userLocation, setUserLocation] = useState(null);
const mapRef = useRef(null);
const { UserLatitudeContext,updateUserLatitudeContext } = useContext(GeneralContext);
const { UserLongitudeContext,updateUserLongitudeContext } = useContext(GeneralContext);
const camera = useRef(null);
const [visible, setVisible] = useState(false); //To make Modal visible or not
const [visibleMenu, setVisibleMenu] = useState(false); //To make Modal visible or not

//Selection des moyens de paiement
const [Wallet, setWallet] = useState(true)
const [Orange, setOrange] = useState(false)
const [Wave, setWave] = useState(false)
const [Visa, setVisa] = useState(false)
const [Cash, setCash] = useState(false)




/*useEffect(() => {
    Mapbox.setStyleURL('mapbox://styles/mapbox/streets-v11'); 
  }, []);*/

  const [carCoordinates, setCarCoordinates] = useState([UserLongitudeContext+0.0010, UserLatitudeContext+0.0008]);


  const SelectPaymentMethod = (arg) => {

    if(arg=="WALLET"){
        setWallet(true);
        setOrange(false);
        setWave(false);
        setVisa(false);
        setCash(false)
    }
   /* else if (arg=="OM"){
        setWallet(false);
        setOrange(true);
        setWave(false);
        setVisa(false);
        setCash(false)
    }
    else if (arg=="WAVE"){
        setWallet(false);
        setOrange(false);
        setWave(true);
        setVisa(false);
        setCash(false)
    }*/
    else if (arg=="VISA"){
        setWallet(false);
        setOrange(false);
        setWave(false);
        setVisa(true);
        setCash(false)
    }
    else if (arg=="CASH"){
        setWallet(false);
        setOrange(false);
        setWave(false);
        setVisa(false);
        setCash(true)
    }
  }
 

  const showHideModal = ()=> {
    setVisible(!visible);
}
 

const showHideModalMenu = ()=> {
    setVisibleMenu(!visibleMenu);
  }
  
  



  
  
    return (
      <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
        
            <View style={[style.centerContent]}>
                        <View>
                                {/*Header*/}
                                <View style={[{width:width,height:height/2}]}>

                                     <View style={[style.headerBtn,style.centerContent,{zIndex:2,position:'absolute',width:width}]}>

                                                {/**Bouton close */}
                                                <View style={{marginTop:30,marginLeft:0}}>
                                                    <TouchableOpacity style={{width:35}} onPress={()=>{navigation.navigate("ConfirmRide")}}>
                                                        <Image source={require('../assets/leftarrowv.png')} style={{width:30,height:30, marginHorizontal:0}} resizeMode='contain'/>
                                                    </TouchableOpacity>
                                                </View>


                                                <View>
                                                        <Text style={[style.transaction,{color:"#000000",fontSize:18,marginHorizontal:width/3,marginTop:33}]}></Text>   
                                                </View>

                                                <View style={{marginTop:30,marginLeft:20}}>
                                                <TouchableOpacity onPress={()=>{showHideModalMenu()}}>
                                                    <Image source={require('../assets/menuv.png')} style={{width:30,height:30, marginHorizontal:0}} resizeMode='contain'/>
                                                </TouchableOpacity>
                                                </View>  

                                     </View>

                           

                                {/**Map */}        
                            <Mapbox.MapView style={style.HalfMap} ref={mapRef} scrollEnabled={false}>

                                  <Mapbox.Camera zoomLevel={15} 
                                                    centerCoordinate={[UserLongitudeContext,UserLatitudeContext]} 
                                                    ref={camera}
                                    /> 
                                        <Mapbox.PointAnnotation id="point" coordinate={[UserLongitudeContext, UserLatitudeContext]} 
                                        iconImage={require('../assets/pin_tiny.png')}
                                        >
                                            <Mapbox.Callout title="Vous êtes ici" />
                                       
                                        </Mapbox.PointAnnotation>

                                       <Mapbox.PointAnnotation
                                            id="car"
                                            coordinate={carCoordinates}
                                            iconImage={require('../assets/berlinerouge.png')}
                                            >
                                            <Mapbox.Callout title="Vehicle location" />
                                        </Mapbox.PointAnnotation>
                    
                            </Mapbox.MapView>
                                 {/**Ajust button  
                                 <View style={style.ajustLocationButton}>
                                    <TouchableOpacity onPress={()=>{cameraMoveTo()}} style={{marginTop:40,marginLeft:10}}>
                                        <Image   source={require("../assets/ajust.png")}
                                            style={{width:46,height:46}} 
                                            resizeMode='contain' /> 
                                    </TouchableOpacity>
                                        
                                </View>*/}  

                                </View>

                                <View style={[style.centerContent,{marginTop:8}]}>


                                </View>

                                  {/*Cards*/}
                                    <View style={style.centerContent}>
                                            
                                            <TouchableOpacity onPress={()=>{showHideModal()}} style={[style.VehicleCard,{width:width-20}]}> 
                                            <View style={[{ flexDirection: 'row',width:width}]}>
                                                <View>
                                                        <Image source={require('../assets/eco.png')} style={{width:80,height:80}} resizeMode='contain'/>
                                                </View>

                                                <View>
                                                    <Text style={[style.title,{marginTop:20,marginHorizontal:23,fontSize:15}]}>ECONOMIQUE</Text>
                                                   
                                                    <View style={{flexDirection:'row', marginLeft:20}}>
                                                    <Image source={require('../assets/clock.png')} style={{width:12,height:12}} resizeMode='contain'/>
                                                    <Text> -</Text>
                                                    </View>
                                                   
                                                </View>

                                                <View>
                                                    <Text style={[style.title,{marginTop:20,marginHorizontal:30,fontSize:15}]}>800 CFA</Text>
                                                </View>
                                             </View>
                                            </TouchableOpacity>

                                            <TouchableOpacity onPress={()=>{showHideModal()}} style={[style.VehicleCard,{height:100,width:width-20}]}> 
                                            <View style={[{ flexDirection: 'row',width:width}]}>
                                                <View>
                                                        <Image source={require('../assets/premium.png')} style={{width:80,height:80}} resizeMode='contain'/>
                                                </View>
                                                <View>
                                                    <Text style={[style.title,{marginTop:20,marginHorizontal:23,fontSize:15}]}>PREMIUM</Text>
                                                    <View style={{flexDirection:'row', marginLeft:20}}>
                                                    <Image source={require('../assets/clock.png')} style={{width:12,height:12}} resizeMode='contain'/>
                                                    <Text> -</Text>
                                                    </View>
                                                </View>

                                                <View>
                                                    <Text style={[style.title,{marginTop:20,marginLeft:63,fontSize:15}]}>1000 CFA</Text>
                                                </View>
                                             </View>
                                            </TouchableOpacity>

                                            <TouchableOpacity onPress={()=>{showHideModal()}} style={[style.VehicleCard,{height:100,width:width-20}]}> 
                                            <View style={[{ flexDirection: 'row',width:width}]}>
                                                <View>
                                                        <Image source={require('../assets/business.png')} style={{width:80,height:80}} resizeMode='contain'/>
                                                </View>

                                                <View>
                                                    <Text style={[style.title,{marginTop:20,marginHorizontal:23,fontSize:15}]}>BUSINESS</Text>
                                                    <View style={{flexDirection:'row', marginLeft:20}}>
                                                    <Image source={require('../assets/clock.png')} style={{width:12,height:12}} resizeMode='contain'/>
                                                    <Text> -</Text>
                                                    </View>
                                                </View>

                                                <View>
                                                    <Text style={[style.title,{marginTop:20,marginLeft:63,fontSize:15}]}>1250 CFA</Text>
                                                </View>
                                             </View>
                                            </TouchableOpacity>

                                        <View style={[{marginTop:20}]}>
                                            
                                        </View>

                                    </View>

                              

                        </View>
                        
                    <Modal   isVisible={visible}
                                animationIn="slideInUp" // Animation d'apparition
                                animationOut="slideOutDown" // Animation de disparition
                                onBackdropPress={showHideModal} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.modal}>
                        
                    <View style={style.modalContent}>

                        <View style={[style.Modal,{height:height/2.2}]}>


                            <TouchableOpacity style={style.btnCloseModal} onPress={()=>{showHideModal()}}>
                                <Image source={require("../assets/close.png")} 
                                        style={[style.tinyIcon]}
                                        resizeMode='contain' /> 
                            </TouchableOpacity>

                        <View style={[style.centerContent,{marginTop:-20}]}>             
                           
                                      <View >
                                        <Text style={[style.invoiceText,{fontSize:18,color:"#000000", marginLeft:7,marginTop:-23}]}>Options de paiement </Text>
                                     </View>

                                     <TouchableOpacity onPress={()=>{SelectPaymentMethod("WALLET")}} style={{flexDirection:'row'}}>
                                        <View style={{marginLeft:20}}>
                                        <Image source={require("../assets/walletw.png")} 
                                        style={[style.invoicePhoto,{width:40,height:40}]}
                                        resizeMode='cover' />
                                        </View>

                                        <View>
                                        <Text style={[style.title,{marginTop:35, marginLeft:20,fontSize:15}]}>Wallet</Text>
                                        </View>

                                        <View style={{flex:1,alignItems:'flex-end', marginRight:20}}>
                                        {Wallet  && <Image source={require("../assets/gcircle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' /> }

                                        {!Wallet  && <Image source={require("../assets/circle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' /> }
                                        </View>
                                        
                                        
                                     </TouchableOpacity>

                                    {/**OM 
                                     <TouchableOpacity onPress={()=>{SelectPaymentMethod("OM")}} style={{flexDirection:'row'}}>
                                        <View style={{marginLeft:20}}>
                                        <Image source={require("../assets/OM.jpg")} 
                                        style={[style.invoicePhoto,{width:34,height:34}]}
                                        resizeMode='cover' />
                                        </View>

                                        <View>
                                        <Text style={[style.title,{marginTop:35, marginLeft:20,fontSize:15}]}>Orange Money</Text>
                                        </View>

                                        <View style={{flex:1,alignItems:'flex-end', marginRight:20}}>
                                         {!Orange && <Image source={require("../assets/circle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' /> }
                                        {Orange && <Image source={require("../assets/gcircle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' /> }
                                        </View>
                                        
                                        
                                     </TouchableOpacity>*/}

                                    {/**Wave
                                     <TouchableOpacity onPress={()=>{SelectPaymentMethod("WAVE")}} style={{flexDirection:'row'}}>
                                        <View style={{marginLeft:20}}>
                                        <Image source={require("../assets/wave.png")} 
                                        style={[style.invoicePhoto,{width:34,height:34}]}
                                        resizeMode='cover' />
                                        </View>

                                        <View>
                                        <Text style={[style.title,{marginTop:35, marginLeft:20,fontSize:15}]}>Wave</Text>
                                        </View>

                                        <View style={{flex:1,alignItems:'flex-end', marginRight:20}}>
                                       {!Wave && <Image source={require("../assets/circle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' /> }
                                        {Wave && <Image source={require("../assets/gcircle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' /> }
                                        </View>
                                        
                                        
                                     </TouchableOpacity> */}
                                    
                                    {/**VISA */}
                                     <TouchableOpacity onPress={()=>{SelectPaymentMethod("VISA")}} style={{flexDirection:'row'}}>
                                        <View style={{marginLeft:20}}>
                                        <Image source={require("../assets/visa.png")} 
                                        style={[style.invoicePhoto,{width:34,height:34}]}
                                        resizeMode='cover' />
                                        </View>

                                        <View>
                                        <Text style={[style.title,{marginTop:35, marginLeft:20,fontSize:15}]}>Carte de crédit</Text>
                                        </View>

                                        <View style={{flex:1,alignItems:'flex-end', marginRight:20}}>
                                        {!Visa && <Image source={require("../assets/circle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' />}

                                        {Visa && <Image source={require("../assets/gcircle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' />}
                                        </View>
                                        
                                        
                                     </TouchableOpacity>
                                     
                                    {/**Cash */}
                                     <TouchableOpacity onPress={()=>{SelectPaymentMethod("CASH")}} style={{flexDirection:'row'}}>
                                        <View style={{marginLeft:20}}>
                                        <Image source={require("../assets/money.png")} 
                                        style={[style.invoicePhoto,{width:34,height:34}]}
                                        resizeMode='cover' />
                                        </View>

                                        <View>
                                        <Text style={[style.title,{marginTop:35, marginLeft:20,fontSize:15}]}>Espèces</Text>
                                        </View>

                                        <View style={{flex:1,alignItems:'flex-end', marginRight:20}}>
                                        {!Cash && <Image source={require("../assets/circle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' /> }

                                        {Cash && <Image source={require("../assets/gcircle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' /> }
                                        </View>
                                        
                                        
                                     </TouchableOpacity>


                                <TouchableOpacity onPress={()=>{showHideModal();navigation.navigate("SeekDriver")}} style={[style.secondButtonMiddleContent,{width:width-20} ]}>
                                    <Text style={[style.textButtonCmdCourse]}>Valider</Text> 
                                </TouchableOpacity>
                        
                        </View>

                        </View>


                    </View>

                    </Modal>

                    <Modal isVisible={visibleMenu}
                                animationIn="slideInRight" // Animation d'apparition
                                animationOut="slideOutRight" // Animation de disparition
                                onBackdropPress={showHideModalMenu} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.menuModal}>
                        
                         <View style={[style.centerContent]}>
                       

                        <View style={[{height:height, width:width-50}]}>
                            
                            <Menu/>
                          
                        </View>


                         </View>

                  </Modal>

            </View>
   
       </SafeAreaView>
      
    )
}