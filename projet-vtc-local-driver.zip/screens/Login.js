import { View,Dimensions,Image,Text,TouchableOpacity,TextInput,ToastAndroid,SafeAreaView } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';


const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function Login() {

const navigation = useNavigation();

function infoCountry (){

    ToastAndroid.showWithGravityAndOffset(
        'En ce moment, nous sommes uniquement présents en Côte d\'ivoire',
        ToastAndroid.LONG,
        ToastAndroid.BOTTOM,
        25,
        50,
      )
}
    
    return (
        <SafeAreaView style={{backgroundColor:"#ffffff",height:height}}>
              <View style={[style.centerContent]}>
                
                <Image source={require("../assets/woyologov_t.png")} 
                style={style.woyoLogo}
                resizeMode='contain' /> 

                {/** Numéro de téléphone */}
                 <View style={style.inputContainer}>
                    
                <TouchableOpacity onPress={()=>{infoCountry()}}>
                <Image source={require("../assets/ivory-coast.png")} 
                    style={style.tinyIcon}
                    /> 
                </TouchableOpacity>

                    <TextInput style={style.inputStyle} 
                    maxLength={10}
                    keyboardType="phone-pad" 
                    placeholder="N° Téléphone" placeholderTextColor="gray"/>
                    
                 </View>
                 <TouchableOpacity onPress={()=>{navigation.navigate("OTP")}} style={[style.secondButtonMiddleContent,{width:width-20} ]}>
                    <Text style={style.textButtonCmdCourse}>Connectez vous</Text> 
                </TouchableOpacity>

                {/** Autres options */}

                <View style={{marginTop:35}}>
                <TouchableOpacity style={{alignItems:'center',justifyContent:'center'}} onPress={()=>{navigation.navigate("SignUp")}}>
                    <Text style={[style.textButtonCmdCourse,{color:"#543090",textDecorationStyle:'solid',textDecorationLine:'underline'}]}>Vous n'avez pas de compte ?</Text>
                    <Text style={[style.textButtonCmdCourse,{color:"#543090",textDecorationStyle:'solid',textDecorationLine:'underline'}]}>Inscrivez vous ici </Text> 
                </TouchableOpacity>
                </View>
                
             </View>
        </SafeAreaView>
          
      
    )
}