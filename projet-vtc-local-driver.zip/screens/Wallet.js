import { View, Text,Dimensions,Image,TouchableOpacity,RefreshControl,ToastAndroid,ScrollView } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import Modal from 'react-native-modal';



const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function Wallet() {

const navigation = useNavigation();
const [balance,setbalance] = useState(0);
const [refreshing, setRefreshing] = useState(false);
//Modal + de services
const [isModalVisible, setModalVisible] = useState(false);


const toggleModal = () => {
  setModalVisible(!isModalVisible);
};


const onRefresh = () => {
    // Mettez à jour l'état de rafraîchissement
    setRefreshing(true);
  
    // Effectuez les actions de rafraîchissement (ex. : récupération de nouvelles données)

    ToastAndroid.showWithGravityAndOffset(
      'Le solde a été mis à jour',
      ToastAndroid.LONG,
      ToastAndroid.BOTTOM,
      25,
      50,
    );
    // Mettez à jour l'état de rafraîchissement après avoir terminé les actions de rafraîchissement
    setRefreshing(false);
  };


  const Remittance = () => {


    ToastAndroid.showWithGravityAndOffset(
      'Votre compte n\'est pas encore actif',
      ToastAndroid.LONG,
      ToastAndroid.BOTTOM,
      25,
      50,
    );

  };

    
    return (
      <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
        <ScrollView refreshControl={
            <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            />
        } > 
        
            <View style={[style.centerContent]}>
                        <View>
                            
                                {/*Header*/}
                                <View style={[style.boxRoundedHeader,{backgroundColor:"#ddd5ea",height:height/1.8}]}>

                                      {/**Bouton close */}
                                <View style={{marginLeft:60,marginTop:15,zIndex:2,position:'absolute'}}>
                                <TouchableOpacity style={{width:35}} onPress={()=>{navigation.navigate("Home")}}>
                                    <Image source={require('../assets/close.png')} style={style.tinyIcon} resizeMode='contain'/>
                                </TouchableOpacity>
                                </View>
                                    
                                <View style={style.centerContent}>
                                    <Image source={require("../assets/refresh.png")} 
                                        style={[style.refreshIcon,{marginTop:15}]}
                                        resizeMode='contain' /> 
                                    <Text style={style.text}>Solde actuel</Text>

                                    {/**solde en CFA */}
                                    <View style={[style.centerContent,{marginTop:20,height:80,backgroundColor:"#ffffff",borderRadius:50,minWidth:180,padding:10,paddingLeft:20,paddingRight:20}]}>
                                        
                                    <Text style={[style.invoiceText,{fontSize:35,color:"#000000",marginTop:0,fontFamily:"Poppins-Bold"}]}>
                                    {balance} CFA</Text>
                                
                                    </View>

                                  
                                    <View style={{flexDirection:'row',display:'flex',marginTop:30}}> 
                                        <Text style={[style.textWalletHeader,{marginTop:0}]}>Mon </Text> 
                                        <Text style={{margin:5, marginTop:-20 }}><Image source={require('../assets/woyologov.png')} style={[{width:70,height:35}]} resizeMode='contain' /></Text>
                                        <Text style={[style.textWalletHeader,{marginTop:0}]}>Wallet </Text> 
                                    </View> 
                                  

                                    {/**Button */}
                                    <View style={[style.centerContent,{flexDirection:'row',marginTop:5}]}> 
                                        <TouchableOpacity  onPress={()=>{ navigation.navigate("RechargeWallet") }} style={[style.secondButtonMiddleContent,{width:130,backgroundColor:"#12ed93",marginHorizontal:5} ]}>
                                            <Text style={[style.textButtonCmdCourse]}>Recharger</Text> 
                                        </TouchableOpacity>

                                        <TouchableOpacity onPress={()=>{ toggleModal() }} style={[style.secondButtonMiddleContent,{width:130,backgroundColor:"#12ed93",marginHorizontal:5} ]}>
                                            <Text style={[style.textButtonCmdCourse]}>+ De services</Text> 
                                        </TouchableOpacity>
                                    </View>


                                </View>

                                </View>

                            <View style={style.main}>
                                {/*Transactions*/}
                                <View style={[style.centerContent, { flexDirection: 'row',paddingLeft:60,paddingRight:60}]}>
                                <Text style={[style.transaction, {flex: 1 }]}>Payé</Text>
                                <Text style={[style.transaction, { textAlign: 'right' }]}>- 1500 CFA</Text>
                                 </View>
                                <Text style={[style.text, {flex: 1,paddingLeft:60, marginTop:0 }]}>Paiement effectuée le 13/07/23</Text>


                                <View style={[style.centerContent, { flexDirection: 'row',paddingLeft:60,paddingRight:60}]}>
                                <Text style={[style.transaction, {flex: 1 }]}>Rechargé</Text>
                                <Text style={[style.transaction, { textAlign: 'right' }]}>+ 3000 CFA</Text>
                                 </View>
                                <Text style={[style.text, {flex: 1,paddingLeft:60, marginTop:0 }]}>Rechargement Wallet effectué le 13/07/23</Text>
                           
                             </View>

                        </View>
            </View>
        
         </ScrollView>

          {/* Modal du menu*/}
          <Modal
                                isVisible={isModalVisible}
                                animationIn="slideInUp" // Animation d'apparition
                                animationOut="slideOutDown" // Animation de disparition
                                onBackdropPress={toggleModal} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.modal}
                              >
                                <View style={style.modalContent}>
                                  {/* Contenu du modal */}
                                
                                                        <View style={[style.Modal,{height:height/2.3}]}>


                                                            <TouchableOpacity style={style.btnCloseModal} onPress={()=>{toggleModal()}}>
                                                                <Image source={require("../assets/close.png")} 
                                                                        style={[style.tinyIcon]}
                                                                        resizeMode='contain' /> 
                                                            </TouchableOpacity>

                             <View style={[{marginTop:-20}]}>             
                                                                    {/*Options support*/}
                                <TouchableOpacity onPress={()=>{toggleModal();navigation.navigate("Withdrawal")}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1,paddingLeft:20,fontSize:16, marginTop:35 }]}>Retrait d'argent</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>

                                 <TouchableOpacity onPress={()=>{toggleModal();Remittance()}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1,paddingLeft:20,fontSize:16, marginTop:35 }]}>Payer sa recette</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>


                            
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10,opacity:0.4}]}>
                                    
                                        <Text style={[style.title, {flex: 1,paddingLeft:20,fontSize:16, marginTop:35 }]}>Demander un crédit</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                            


                             
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10,opacity:0.4}]}>
                                    
                                        <Text style={[style.title, {flex: 1,paddingLeft:20,fontSize:16, marginTop:35 }]}>Payer son carburant</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                             


                                                        <View>
                              
                            </View>
                          </View>
                         </View>
                        </View>
                      </Modal>

      
       </SafeAreaView>
      
    )
}