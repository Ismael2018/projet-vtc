import { View, Text,Dimensions,Image,TouchableOpacity,RefreshControl,ToastAndroid,ScrollView,TextInput } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import BottomComponent from '../navigator/BottomComponent';
import Modal from 'react-native-modal';



const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function RechargeWallet() {

const navigation = useNavigation();
const [balance,setbalance] = useState(0);
const [refreshing, setRefreshing] = useState(false);
const [phoneNumber, setphoneNumber] = useState("0749793919");
const [visible, setVisible] = useState(false); //To make Modal visible or not

//Selection des moyens de paiement
const [Mtn, setMtn] = useState(true)
const [Orange, setOrange] = useState(false)
const [Wave, setWave] = useState(false)
const [Visa, setVisa] = useState(false)
const [Cash, setCash] = useState(false)


const onRefresh = () => {
    // Mettez à jour l'état de rafraîchissement
    setRefreshing(true);
  
    // Effectuez les actions de rafraîchissement (ex. : récupération de nouvelles données)

    ToastAndroid.showWithGravityAndOffset(
      'Le solde a été mis à jour',
      ToastAndroid.LONG,
      ToastAndroid.BOTTOM,
      25,
      50,
    );
    // Mettez à jour l'état de rafraîchissement après avoir terminé les actions de rafraîchissement
    setRefreshing(false);
  };


  const SelectPaymentMethod = (arg) => {

    if(arg=="MTN"){
        setMtn(true);
        setOrange(false);
        setWave(false);
        setVisa(false);
        setCash(false)
    }
    else if (arg=="OM"){
        setMtn(false);
        setOrange(true);
        setWave(false);
        setVisa(false);
        setCash(false)
    }
    else if (arg=="WAVE"){
        setMtn(false);
        setOrange(false);
        setWave(true);
        setVisa(false);
        setCash(false)
    }
    else if (arg=="VISA"){
        setMtn(false);
        setOrange(false);
        setWave(false);
        setVisa(true);
        setCash(false)
    }
    else if (arg=="CASH"){
        setMtn(false);
        setOrange(false);
        setWave(false);
        setVisa(false);
        setCash(true)
    }
  }
 

  const showHideModal = ()=> {
    setVisible(!visible);
}
 

  function infoCountry (){

    ToastAndroid.showWithGravityAndOffset(
        'En ce moment, nous sommes uniquement présents en Côte d\'ivoire',
        ToastAndroid.LONG,
        ToastAndroid.BOTTOM,
        25,
        50,
      )
}

    
    return (
      <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
        <ScrollView refreshControl={
            <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            />
        } > 
        
            <View style={[style.centerContent]}>
                        <View>
                                {/*Header*/}
                                <View style={[{backgroundColor:"#ddd5ea",width:width,height:height/2.5}]}>

                                {/**Bouton close */}
                                <View style={{marginTop:30,marginLeft:20}}>
                                <TouchableOpacity style={{width:35}} onPress={()=>{navigation.navigate("Wallet")}}>
                                    <Image source={require('../assets/close.png')} style={style.tinyIcon} />
                                </TouchableOpacity>
                                </View>
                                    
                                <View style={style.centerContent}>
                                    <Image source={require("../assets/refresh.png")} 
                                        style={[style.refreshIcon,{marginTop:-30}]}
                                        resizeMode='contain' /> 
                                    <Text style={style.text}>Solde actuel</Text>

                                    {/**solde en CFA */}
                                    <View style={[style.centerContent,{marginTop:20,height:80,backgroundColor:"#ffffff",borderRadius:50,minWidth:180,padding:10,paddingLeft:20,paddingRight:20}]}>
                                        
                                    <Text style={[style.invoiceText,{fontSize:35,color:"#000000",marginTop:0,fontFamily:"Poppins-Bold"}]}>
                                    {balance} CFA</Text>
                                
                                    </View>

                                  
                                    <View style={{flexDirection:'row',display:'flex',marginTop:30}}> 
                                        <Text style={[style.textWalletHeader,{marginTop:0}]}>Mon </Text> 
                                        <Text style={{margin:5, marginTop:-20 }}><Image source={require('../assets/woyologov.png')} style={[{width:70,height:35}]} resizeMode='contain' /></Text>
                                        <Text style={[style.textWalletHeader,{marginTop:0}]}>Wallet </Text> 
                                    </View> 
                                  


                                </View>

                                </View>

                                <View style={[style.centerContent,{marginTop:20}]}>
                                    <Text style={[style.invoiceText,{fontSize:20,color:"#000000"}]}>Saisissez les informations </Text>
                                    <Text style={[style.invoiceText,{fontSize:20,color:"#000000",marginTop:0}]}>de la transaction </Text>
                                </View>

                                <View style={[style.main,style.centerContent]}>
                                   
                                    {/** Numéro de téléphone */}
                                    <View style={style.inputContainer}>
                                        
                                        <TouchableOpacity onPress={()=>{infoCountry()}}>
                                        <Image source={require("../assets/ivory-coast.png")} 
                                            style={style.tinyIcon}
                                            /> 
                                        </TouchableOpacity>
                        
                                            <TextInput style={style.inputStyle} 
                                            maxLength={10}
                                            keyboardType="phone-pad" 
                                            placeholder="N° Téléphone"
                                            value={phoneNumber}
                                            onChangeText={newText => {setphoneNumber(newText)}} 
                                            placeholderTextColor="gray"
                                            />
                                            
                                    </View>

                                    {/** Montant */}
                                    <View style={[style.inputContainer,{marginTop:15}]}>
                            
                                        <TextInput style={[style.inputStyle,{width:width-50}]}  
                                        placeholder="Montant du rechargement"
                                        keyboardType='phone-pad' />
                                        
                                    </View>


                                    <TouchableOpacity onPress={()=>{showHideModal()}} style={[style.secondButtonMiddleContent,{width:width-150,marginTop:20} ]}>
                                        <Text style={style.textButtonCmdCourse}>Valider</Text> 
                                    </TouchableOpacity>

                                </View>

                        </View>
            </View>
        
         </ScrollView>

         <Modal   isVisible={visible} 
                                animationIn="slideInUp" // Animation d'apparition
                                animationOut="slideOutDown" // Animation de disparition
                                onBackdropPress={showHideModal} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.modal}>
                        
                    <View style={style.modalContent}>

                        <View style={[style.Modal,{height:height/1.65}]}>


                            <TouchableOpacity style={style.btnCloseModal} onPress={()=>{showHideModal()}}>
                                <Image source={require("../assets/close.png")} 
                                        style={[style.tinyIcon]}
                                        resizeMode='contain' /> 
                            </TouchableOpacity>

                        <View style={[style.centerContent,{marginTop:-20}]}>             
                           
                                      <View >
                                        <Text style={[style.invoiceText,{fontSize:18,color:"#000000", marginLeft:7,marginTop:-23}]}>Options de paiement </Text>
                                     </View>

                                     <TouchableOpacity onPress={()=>{SelectPaymentMethod("MTN")}} style={{flexDirection:'row'}}>
                                        <View style={{marginLeft:20}}>
                                        <Image source={require("../assets/Momo.jpg")} 
                                        style={[style.invoicePhoto,{width:34,height:34}]}
                                        resizeMode='cover' />
                                        </View>

                                        <View>
                                        <Text style={[style.title,{marginTop:35, marginLeft:20,fontSize:15}]}>MTN MoMo</Text>
                                        </View>

                                        <View style={{flex:1,alignItems:'flex-end', marginRight:20}}>
                                        {Mtn  && <Image source={require("../assets/gcircle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' /> }

                                        {!Mtn  && <Image source={require("../assets/circle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' /> }
                                        </View>
                                        
                                        
                                     </TouchableOpacity>

                                    {/**OM */}
                                     <TouchableOpacity onPress={()=>{SelectPaymentMethod("OM")}} style={{flexDirection:'row'}}>
                                        <View style={{marginLeft:20}}>
                                        <Image source={require("../assets/OM.jpg")} 
                                        style={[style.invoicePhoto,{width:34,height:34}]}
                                        resizeMode='cover' />
                                        </View>

                                        <View>
                                        <Text style={[style.title,{marginTop:35, marginLeft:20,fontSize:15}]}>Orange Money</Text>
                                        </View>

                                        <View style={{flex:1,alignItems:'flex-end', marginRight:20}}>
                                         {!Orange && <Image source={require("../assets/circle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' /> }
                                        {Orange && <Image source={require("../assets/gcircle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' /> }
                                        </View>
                                        
                                        
                                     </TouchableOpacity>

                                    {/**Wave */}
                                     <TouchableOpacity onPress={()=>{SelectPaymentMethod("WAVE")}} style={{flexDirection:'row'}}>
                                        <View style={{marginLeft:20}}>
                                        <Image source={require("../assets/wave.png")} 
                                        style={[style.invoicePhoto,{width:34,height:34}]}
                                        resizeMode='cover' />
                                        </View>

                                        <View>
                                        <Text style={[style.title,{marginTop:35, marginLeft:20,fontSize:15}]}>Wave</Text>
                                        </View>

                                        <View style={{flex:1,alignItems:'flex-end', marginRight:20}}>
                                       {!Wave && <Image source={require("../assets/circle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' /> }
                                        {Wave && <Image source={require("../assets/gcircle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' /> }
                                        </View>
                                        
                                        
                                     </TouchableOpacity>
                                    
                                    {/**VISA */}
                                     <TouchableOpacity onPress={()=>{SelectPaymentMethod("VISA")}} style={{flexDirection:'row'}}>
                                        <View style={{marginLeft:20}}>
                                        <Image source={require("../assets/visa.png")} 
                                        style={[style.invoicePhoto,{width:34,height:34}]}
                                        resizeMode='cover' />
                                        </View>

                                        <View>
                                        <Text style={[style.title,{marginTop:35, marginLeft:20,fontSize:15}]}>Carte de crédit</Text>
                                        </View>

                                        <View style={{flex:1,alignItems:'flex-end', marginRight:20}}>
                                        {!Visa && <Image source={require("../assets/circle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' />}

                                        {Visa && <Image source={require("../assets/gcircle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26}]}
                                        resizeMode='cover' />}
                                        </View>
                                        
                                        
                                     </TouchableOpacity>
                                     
                                    {/**Cash */}
                                     <TouchableOpacity  style={{flexDirection:'row',opacity:0.5}}>
                                        <View style={{marginLeft:20}}>
                                        <Image source={require("../assets/money.png")} 
                                        style={[style.invoicePhoto,{width:34,height:34,opacity:0.5}]}
                                        resizeMode='cover' />
                                        </View>

                                        <View>
                                        <Text style={[style.title,{marginTop:35, marginLeft:20,fontSize:15}]}>Espèces</Text>
                                        </View>

                                        <View style={{flex:1,alignItems:'flex-end', marginRight:20}}>
                                        {!Cash && <Image source={require("../assets/circle.png")} 
                                        style={[style.invoicePhoto,{width:26,height:26,opacity:0.5}]}
                                        resizeMode='cover' /> }

                                    
                                        </View>
                                        
                                        
                                     </TouchableOpacity>


                                <TouchableOpacity onPress={()=>{showHideModal()}} style={[style.secondButtonMiddleContent,{width:width-20} ]}>
                                    <Text style={[style.textButtonCmdCourse]}>Valider</Text> 
                                </TouchableOpacity>
                        
                        </View>

                        </View>


                    </View>

                    </Modal>

          
       </SafeAreaView>
      
    )
}