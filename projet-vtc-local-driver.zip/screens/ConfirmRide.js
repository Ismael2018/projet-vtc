import { View, Text,Dimensions,Image,TouchableOpacity,ToastAndroid,TextInput } from 'react-native'
import React, { useState, useRef, useContext, useEffect  } from 'react'
import { PrivateValueStore, useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import Mapbox, { Camera, UserLocation  } from '@rnmapbox/maps';
import Token from '../mapBoxToken';
import { GeneralContext } from '../context';
import Modal from 'react-native-modal';
import Menu from './Menu';



const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

Mapbox.setWellKnownTileServer('Mapbox');
Mapbox.setAccessToken(Token);

export default function ConfirmRide() {

const navigation = useNavigation();
const [favourite, setfavourite] = useState(false);
const [userLocation, setUserLocation] = useState(null);
const mapRef = useRef(null);
const { UserLatitudeContext,updateUserLatitudeContext } = useContext(GeneralContext);
const { UserLongitudeContext,updateUserLongitudeContext } = useContext(GeneralContext);
const camera = useRef(null);
const [isMultipleStopModalVisible, setisMultipleStopModalVisible] = useState(false); //To make Modal visible or not
const [nbMultipleStops, setnbMultipleStops] = useState([]);
const [visibleMenu, setVisibleMenu] = useState(false); //To make Modal visible or not



/*useEffect(() => {
    Mapbox.setStyleURL('mapbox://styles/mapbox/streets-v11'); 
  }, []);*/

  const [carCoordinates, setCarCoordinates] = useState([UserLongitudeContext+0.0010, UserLatitudeContext+0.0008]);

  const showMSHideModal = ()=> {
    setisMultipleStopModalVisible(!isMultipleStopModalVisible);
}

//Pour ajouter les arrêts
const [isModalVisible, setModalVisible] = useState(false);

const toggleModal = () => {
  setModalVisible(!isModalVisible);
};


//Pour supprimer les arrêts
const [isModalVisible_, setModalVisible_] = useState(false);

const toggleModal_ = () => {
  setModalVisible_(!isModalVisible_);
};


const showHideModalMenu = ()=> {
  setVisibleMenu(!visibleMenu);
}


 

//Ajouter des arrêts
const addMS = (arg) => {
 
  
   //Vérifie cet arrêt est déja ajouté dans notre tableau

   if (!nbMultipleStops.includes(arg)) {
    // Si la valeur n'existe pas déjà dans le tableau, on l'insère
    setnbMultipleStops([...nbMultipleStops, arg]);
    toggleModal()
  }
  else{
    ToastAndroid.showWithGravityAndOffset(
      'Vous avez déja ajouté cette destination comme arrêt',
      ToastAndroid.LONG,
      ToastAndroid.BOTTOM,
      25,
      50,
    );
  }


console.log("nb multiple stops: "+nbMultipleStops.length)

}


//Supprimer des arrêts
const deleteStops = (valueToRemove) => {
  const updatedArray = nbMultipleStops.filter((value) => value !== valueToRemove);
  setnbMultipleStops(updatedArray);
};

const infoMS = ()=> {

  ToastAndroid.showWithGravityAndOffset(
    'Vous ne pouvez plus ajouter de nouveaux arrêts',
    ToastAndroid.LONG,
    ToastAndroid.BOTTOM,
    25,
    50,
  );

}



  
  
    return (
      <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
        
            <View style={[style.centerContent]}>
                        <View >
                                {/*Header*/}
                                <View style={[{width:width,height:height/2}]}>

                                     <View style={[style.headerBtn,style.centerContent,{zIndex:2,position:'absolute',width:width}]}>

                                                {/**Bouton close */}
                                                <View style={{marginTop:30,marginLeft:0}}>
                                                    <TouchableOpacity style={{width:35}} onPress={()=>{navigation.navigate("Home")}}>
                                                        <Image source={require('../assets/closev.png')} style={{width:30,height:30, marginHorizontal:0}} resizeMode='contain'/>
                                                    </TouchableOpacity>
                                                </View>


                                                <View>
                                                        <Text style={[style.transaction,{color:"#000000",fontSize:18,marginHorizontal:width/3,marginTop:33}]}></Text>   
                                                </View>

                                                <View style={{marginTop:30,marginLeft:20}}>
                                                <TouchableOpacity onPress={()=>{showHideModalMenu()}}>
                                                    <Image source={require('../assets/menuv.png')} style={{width:30,height:30, marginHorizontal:0}} resizeMode='contain'/>
                                                </TouchableOpacity>
                                                </View>  

                                     </View>

                           

                                {/**Map */}        
                            <Mapbox.MapView style={style.HalfMap} ref={mapRef} scrollEnabled={false}>

                                  <Mapbox.Camera zoomLevel={15} 
                                                    centerCoordinate={[UserLongitudeContext,UserLatitudeContext]} 
                                                    ref={camera}
                                    /> 
                                        <Mapbox.PointAnnotation id="point" coordinate={[UserLongitudeContext, UserLatitudeContext]} 
                                        iconImage={require('../assets/pin_tiny.png')}
                                        >
                                            <Mapbox.Callout title="Vous êtes ici" />
                                       
                                        </Mapbox.PointAnnotation>

                                       <Mapbox.PointAnnotation
                                            id="car"
                                            coordinate={carCoordinates}
                                            iconImage={require('../assets/berlinerouge.png')}
                                            >
                                            <Mapbox.Callout title="Vehicle location" />
                                        </Mapbox.PointAnnotation>
                    
                            </Mapbox.MapView>
                                 {/**Ajust button  
                                 <View style={style.ajustLocationButton}>
                                    <TouchableOpacity onPress={()=>{cameraMoveTo()}} style={{marginTop:40,marginLeft:10}}>
                                        <Image   source={require("../assets/ajust.png")}
                                            style={{width:46,height:46}} 
                                            resizeMode='contain' /> 
                                    </TouchableOpacity>
                                        
                                </View>*/}  

                                </View>


                                {/**Bloc du bas */}
                                <View>
                        
                                <View style={[style.centerContent,{marginTop:8}]}>

                                    <View style={style.swipedCursor}></View>
                                    
                                    <View style={{flexDirection:'row'}}>
                                      <View style={{flex:1, marginLeft:10}}>
                                        <Text style={[style.invoiceText,{fontSize:18,color:"#000", marginLeft:7}]}>Détails de la course </Text>
                                     </View>
                                     
                                     {/**Plus d'options = Programmer un trajet + Commander une course pour quelqu'un*
                                      Si 3 arrêts sont ajoutés, on ne permet plus d'ajouter de nouveaux arrêts*/}


                                      {nbMultipleStops.length<3 && <TouchableOpacity onPress={()=>{ toggleModal() }}>
                                      <View style={{marginRight:10,flexDirection:'row'}}>
                                            <View> 
                                                <Image source={require("../assets/plus.png")}
                                                style={{width:17,height:17,marginTop:29}} 
                                                resizeMode='contain' /> 
                                            </View>

                                            <View style={{marginHorizontal:5}}>
                                            <Text style={[style.invoiceText,{fontSize:9,color:"#000"}]}> Ajouter</Text>
                                            <Text style={[style.invoiceText,{fontSize:9,color:"#000",marginTop:-5.5,marginLeft:2}]}>des arrêts</Text>
                                            </View>
                                         </View>
                                      </TouchableOpacity> }

                                      {nbMultipleStops.length==3 && <TouchableOpacity onPress={()=>{ infoMS() }}>
                                      <View style={{marginRight:10,flexDirection:'row'}}>
                                            <View> 
                                                <Image source={require("../assets/plus.png")}
                                                style={{width:17,height:17,marginTop:29}} 
                                                resizeMode='contain' /> 
                                            </View>

                                            <View style={{marginHorizontal:5}}>
                                            <Text style={[style.invoiceText,{fontSize:9,color:"#000"}]}> Ajouter</Text>
                                            <Text style={[style.invoiceText,{fontSize:9,color:"#000",marginTop:-5.5,marginLeft:2}]}>des arrêts</Text>
                                            </View>
                                         </View>
                                      </TouchableOpacity> }
                                    </View>

                                {/** Détails */}
                                <View style={[style.centerContent,{marginTop:35}]}>
                                   
                                   {/*Pickup & Drop Location*/}
                                    <View>

                                             <View style={[style.centerContent, { flexDirection: 'row',width:width-40}]}>
                                                <Text style={[style.title, {fontSize:15,flex: 1,marginTop: -8}]}>Bridge Bank.Plateau Rue du commerce</Text>
                                            
                                                
                                                <View style={[style.transaction,{textAlign: 'right',marginTop:-8,marginHorizontal:5,flexDirection:'row'}]}>
                                                
                                                <TouchableOpacity onPress={()=>{navigation.navigate("SearchPickUp")}}>
                                                 <Image source={require('../assets/right-arrown.png')} style={{width:18,height:18}} resizeMode='contain'/>
                                                </TouchableOpacity>
                                                  
                                                </View>
                                                </View>

                                                <Text style={[style.text, {marginTop: 0}]}>Abidjan 24 CI, Rue F16</Text>

                                               {/**Si il n'y a pas d'arrêts on affiche ce bloc*/}

                                                {nbMultipleStops.length==0 && <View style={[style.centerContent, { flexDirection: 'row',width:width-40,marginTop:30}]}>

                                                   <Text style={[style.title, {fontSize:15,flex: 1,marginTop: -8}]}>Aéroport Félix Houphouet B.</Text>
                                            
                                               

                                                 <View style={[style.transaction,{textAlign: 'right',marginTop:-8,marginHorizontal:5}]}>

                                                     <View style={[style.transaction,{textAlign: 'right',marginTop:-8,marginHorizontal:5}]}>

                                                     <TouchableOpacity onPress={()=>{navigation.navigate("SearchDestination")}}>
                                                        <Image source={require('../assets/right-arrown.png')} style={{width:18,height:18}} resizeMode='contain'/>
                                                    </TouchableOpacity>
                                                     </View>
                                                 
                                                 </View>
                                                </View> }


                                                {/**Si il y a  des arrêts on affiche ce bloc*/}

                                                {nbMultipleStops.length>0 && <View style={[style.centerContent, { flexDirection: 'row',width:width-40,marginTop:30}]}>

                                                   <Text style={[style.title, {fontSize:15,flex: 1,marginTop: -8}]}>Aéroport Félix Houphouet B. + {nbMultipleStops.length} arrêt(s) </Text>
                                            
                                               

                                                 <View style={[style.transaction,{textAlign: 'right',marginTop:-8,marginHorizontal:5}]}>

                                                     <View style={[style.transaction,{textAlign: 'right',marginTop:-8,marginHorizontal:5}]}>

                                                     <TouchableOpacity onPress={()=>{toggleModal_()}}>
                                                        <Image source={require('../assets/right-arrown.png')} style={{width:18,height:18}} resizeMode='contain'/>
                                                    </TouchableOpacity>
                                                     </View>
                                                 
                                                 </View>
                                                </View> }

                                                <Text style={[style.text, {marginTop: 0}]}>Abidjan 07 CI, Rue G47</Text>

                                    </View>
                                   
                                </View>
                               
                                    
                                    <View style={style.centerContent}>
                                    <TouchableOpacity onPress={()=>{navigation.navigate("SelectVehicleCategory")}} style={[style.greenButton,{width:width,height:50,marginTop:18} ]}>
                                        <Text style={[style.textHeaderGiftPoints,{marginTop:5,fontSize:16}]}>Confirmer </Text> 
                                        </TouchableOpacity>
                                    </View>

                                </View>

                              
                                </View>
                               
                               </View>  
                             {/* Modal avec animation pour ajouter les arrêts*/}
                              <Modal
                                isVisible={isModalVisible}
                                animationIn="slideInUp" // Animation d'apparition
                                animationOut="slideOutDown" // Animation de disparition
                                onBackdropPress={toggleModal} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.modal}
                              >
                                <View style={style.modalContent}>
                                  {/* Contenu du modal */}
                                
                                                        <View style={[style.Modal,{height:height/2}]}>


                                                            <TouchableOpacity style={style.btnCloseModal} onPress={()=>{toggleModal()}}>
                                                                <Image source={require("../assets/close.png")} 
                                                                        style={[style.tinyIcon]}
                                                                        resizeMode='contain' /> 
                                                            </TouchableOpacity>

                                                        <View style={[style.centerContent,{marginTop:-20}]}>             
                                                          
                                                            {/** Input recherche */}
                                                              <View style={[style.inputContainer,{height:45,width:width-30}]}>
                                                                        
                                                                          <Image source={require("../assets/search.png")} 
                                                                            style={{width:16,height:16}}
                                                                            /> 

                                                                            <TextInput style={style.inputSearch}
                                                                            placeholder="Saisissez l'adresse" placeholderTextColor="gray"/>
                                                                            
                                                              </View>

                                                                    
                                                              <View >

                                                              <Text style={[style.textHeaderGiftPoints,{color:"#000",width:width-50}]}>
                                                                Derniers trajets
                                                                </Text>

                                                              </View>
                                                            
                                                            {/*Places*/}
                                                              <View>
                                                                      
                                                                        <View style={[style.centerContent, { flexDirection: 'row',width:width-40,marginTop:0}]}>  
                                                                          <View style={{flex:1}}>
                                                                            <TouchableOpacity onPress={()=>{addMS("Aéroport Félix Houphouet B.")}} >
                                                                              <Text style={[style.title, {fontSize:15,marginTop: 20}]}>Aéroport Félix Houphouet B.</Text>
                                                                            </TouchableOpacity>
                                                                            </View>
                                                                      
                                                                          </View>

                                                                          <TouchableOpacity onPress={()=>{addMS("Aéroport Félix Houphouet B.")}} > 
                                                                          <Text style={[style.text, {marginTop: 0}]}>Abidjan 07 CI, Rue G47</Text>
                                                                          </TouchableOpacity>



                                                                          <View style={[style.centerContent, { flexDirection: 'row',width:width-40,marginTop:0}]}>  
                                                                          <View style={{flex:1}}>
                                                                            <TouchableOpacity onPress={()=>{addMS("Bridge Bank Group")}} >
                                                                              <Text style={[style.title, {fontSize:15,marginTop: 20}]}>Bridge Bank Group</Text>
                                                                            </TouchableOpacity>
                                                                            </View>
                                                                      
                                                                          </View>

                                                                          <TouchableOpacity onPress={()=>{addMS("Bridge Bank Group")}} > 
                                                                          <Text style={[style.text, {marginTop: 0}]}>Abidjan 07 CI, Rue du commerce</Text>
                                                                          </TouchableOpacity>
                                                              </View>

                                                          
                                                        
                                                        </View>

                                                        </View>
                              
                                </View>
                              </Modal>

                              {/* Modal avec animation pour supprimer les arrêts*/}
                              <Modal
                                isVisible={isModalVisible_}
                                animationIn="slideInUp" // Animation d'apparition
                                animationOut="slideOutDown" // Animation de disparition
                                onBackdropPress={toggleModal_} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.modal}
                              >
                                <View style={style.modalContent}>
                                  {/* Contenu du modal */}
                                
                                                        <View style={[style.Modal,{height:height/2}]}>


                                                            <TouchableOpacity style={style.btnCloseModal} onPress={()=>{toggleModal_()}}>
                                                                <Image source={require("../assets/close.png")} 
                                                                        style={[style.tinyIcon]}
                                                                        resizeMode='contain' /> 
                                                            </TouchableOpacity>

                                                        <View style={[style.centerContent,{marginTop:-20}]}>             
                                                              
                                                              <View >

                                                              <Text style={[style.textHeaderGiftPoints,{color:"#000",width:width-50}]}>
                                                                Arrêts du trajet
                                                                </Text>

                                                              </View>
                                                            
                                                            {/*Places*/}
                                                              <View>
                                                                       {/* Afficher les valeurs du tableau */}
    
                                                                       {nbMultipleStops.map((value, index) => ( <View key={index} style={[style.centerContent, { flexDirection: 'row',width:width-40,marginTop:15}]}>  
                                                                          <View style={{flex:1}}>
                                                                            <TouchableOpacity onPress={()=>{deleteStops(value)}} >
                                                                              <Text style={[style.title, {fontSize:15,marginTop: 20}]}>{value}</Text>
                                                                            </TouchableOpacity>
                                                                            </View>

                                                                            {/**Bouton close */}
                                                                            <View style={[style.transaction,{textAlign: 'right',marginTop:-8,marginHorizontal:5}]}>
                                                                                                <TouchableOpacity onPress={()=>{deleteStops(value)}}>
                                                                                                  <Image source={require('../assets/remove.png')} style={[style.tinyIcon,{marginTop:30}]} resizeMode='contain'/>
                                                                                                </TouchableOpacity>
                                                                          </View>
                                                                      
                                                                          </View>))}

                                                                        

                                                              </View>

                                                          
                                                        
                                                        </View>

                                                        </View>
                              
                                </View>
                              </Modal>


                              {/**Menu */}
                              <Modal isVisible={visibleMenu}
                                animationIn="slideInRight" // Animation d'apparition
                                animationOut="slideOutRight" // Animation de disparition
                                onBackdropPress={showHideModalMenu} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.menuModal}>
                        
                         <View style={[style.centerContent]}>
                       

                        <View style={[{height:height, width:width-50}]}>
                            
                            <Menu/>
                          
                        </View>


                         </View>

                              </Modal>
                            

                        </View>
       
   
       </SafeAreaView>
      
    )
}

