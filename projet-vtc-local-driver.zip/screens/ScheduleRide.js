import { View, Text,Dimensions,Image,TouchableOpacity,ScrollView,TextInput,ToastAndroid } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import DatePicker from 'react-native-date-picker'
import Menu from './Menu';
import Modal from 'react-native-modal';



const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function ScheduleRide() {

const navigation = useNavigation();
const [date, setDate] = useState(new Date())
const [open, setOpen] = useState(false)
const [hasBeenOpened, setHasBeenOpened] = useState(false)
const [sDate, setSDate] = useState("")
const [visibleMenu, setVisibleMenu] = useState(false); //To make Modal visible or not

var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
var day = currentDate.getDate()
var month = currentDate.getMonth() + 1
var year = currentDate.getFullYear()




function Schedule(){

    ToastAndroid.showWithGravityAndOffset(
        'Tous nos chauffeurs sont indisponibles à cette période',
        ToastAndroid.LONG,
        ToastAndroid.BOTTOM,
        25,
        50,
      )

}


function Logs(){

    setHasBeenOpened(true)
    console.log(date.toISOString().substring(0, 10))
    console.log(date.toISOString().substring(11, 16))

    setSDate((date.toISOString().substring(0, 10))+" à "+(date.toISOString().substring(11, 16)))
}

const showHideModalMenu = ()=> {
    setVisibleMenu(!visibleMenu);
  }
  
    
    return (
        <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
          <ScrollView>
          <View style={[style.centerContent]}>
                      <View>
                            {/*Header*/}
                            <View style={[style.headerBtn,style.centerContent]}>
                              {/**Bouton close */}
                              <View style={{marginTop:30,marginLeft:0}}>
                                <TouchableOpacity style={{width:35}} onPress={()=>{navigation.navigate("OrderRide")}}>
                                    <Image source={require('../assets/closev.png')} style={{width:30,height:30, marginHorizontal:0}} resizeMode='contain'/>
                                </TouchableOpacity>
                                </View>


                                <View >
                                        <Text style={[style.transaction,{color:"#000000",fontSize:18,marginHorizontal:width/3,marginTop:33}]}></Text>   
                                </View>

                                <View style={{marginTop:30,marginLeft:20}}>
                                <TouchableOpacity onPress={()=>{showHideModalMenu()}}>
                                    <Image source={require('../assets/menuv.png')} style={{width:30,height:30, marginHorizontal:0}} resizeMode='contain'/>
                                </TouchableOpacity>
                                </View>  
                            
                            </View>

                            <View style={[style.centerContent,{flexDirection:"row"}]}>
                                <View style={[{marginTop:30}]}> 
                                    <Image source={require('../assets/calendar.png')} style={{width:65,height:65}} resizeMode='contain'/>
                               </View>
                                <View>
                                    <Text style={[style.textWalletHeader,{marginLeft:20}]}>Programmer</Text>
                                    <Text style={[style.textWalletHeader,{marginTop:-7,marginLeft:20}]}>un trajet</Text>
                                    <Text style={[{marginTop:-40,marginLeft:20}]}>
                                        <Image source={require('../assets/woyologov.png')} style={{width:50,height:50}} resizeMode='contain'/></Text>
                                </View>
                            </View>


                    </View>

                    {/** Inputs */}
                 <View style={[style.inputContainer,{height:50,width:width-30}]}>
                
                    <Image source={require("../assets/history.png")} 
                        style={{width:16,height:16}}
                        /> 
                        {!hasBeenOpened && <Text style={[style.text,{marginLeft:10,marginTop:0}]} 
                        onPress={() => setOpen(true)}>
                            Date de réservation
                        </Text>}

                        {hasBeenOpened && <Text style={[style.text,{marginLeft:10,marginTop:0}]} 
                        onPress={() => setOpen(true)}>
                           {sDate}
                        </Text>}

                        <Text>
                     <DatePicker
                            modal
                            open={open}
                            date={date}
                            onDateChange={(date)=>{
                                setDate(date)
                            }}
                            onConfirm={(date) => {
                            setOpen(false)
                            setDate(date)
                            Logs()
                            //minimumDate={minDate}
                            //maximumDate={maxDate}
                            }}
                            onCancel={() => {
                            setOpen(false)
                            }}
                        />
                     </Text>
                        
                     </View>

                

                    

                     <View style={[style.inputContainer,{height:50,marginTop:20,width:width-30}]}>
                
                        <Image source={require("../assets/search.png")} 
                            style={{width:16,height:16}}
                            /> 
                            <TextInput style={style.inputSearch}
                            placeholder="Votre adresse de récupération"
                            placeholderTextColor="gray"
                            />
                            
                    </View>

                    <View style={[style.inputContainer,{height:50,marginTop:20,width:width-30}]}>
                    
                        <Image source={require("../assets/search.png")} 
                            style={{width:16,height:16}}
                            /> 
                            <TextInput style={style.inputSearch}
                            placeholder="Entrez votre destination"
                            placeholderTextColor="gray"
                            />
                        
                    </View>

                        <View style={[{height:25}]}>
                            
                        </View>
                           

                        <View style={style.centerContent}>
                                    <TouchableOpacity onPress={()=>{Schedule()}} style={[style.greenButton,{width:width-20,height:50,marginTop:18} ]}>
                                        <Text style={[style.textHeaderGiftPoints,{marginTop:5,fontSize:16}]}>Confirmer </Text> 
                                        </TouchableOpacity>
                            </View>


                            {/*Pub*/}
                            <View style={[style.centerContent]}>
                            <Image
                                source={require("../assets/pub.jpg")}
                                style={style.advertisingBanner} resizeMode='contain' /> 
                            </View>

                          
             

                  

        </View>
          </ScrollView>

          <Modal isVisible={visibleMenu}
                                animationIn="slideInRight" // Animation d'apparition
                                animationOut="slideOutRight" // Animation de disparition
                                onBackdropPress={showHideModalMenu} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.menuModal}>
                        
                         <View style={[style.centerContent]}>
                       

                        <View style={[{height:height, width:width-50}]}>
                            
                            <Menu/>
                          
                        </View>


                         </View>

            </Modal>
            
     

        </SafeAreaView>
      
    )
}