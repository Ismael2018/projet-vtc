import { View, Text,Dimensions,Image,TouchableOpacity,ScrollView,TextInput } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import BottomComponent from '../navigator/BottomComponent';
//import BottomComponent from '../navigator/BottomComponent';



const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function Menu() {

const navigation = useNavigation();

    
    return (
        <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
          <View style={[style.centerContent]}>
                      <View>
                            {/*Header*/}
                        


                            <View style={[style.centerContent]}>
                            
                              <View style={{marginTop:20,marginLeft:0}}>
                                <TouchableOpacity  onPress={()=>{navigation.navigate("Profil")}}>
                                    <Image source={require('../assets/account.png')} style={{width:70,height:70}} resizeMode='contain'/>
                                </TouchableOpacity>
                                </View>


                                <View >
                                        <Text style={[style.transaction,{color:"#000000",fontSize:18,marginTop:10}]}>Ismael Tonné</Text>   
                                </View>

                                {/**Points */}
                                <TouchableOpacity onPress={()=>{navigation.navigate('GiftPoints')}}>
                                    
                                    <View style={[style.centerContent,{marginTop:10,height:48,backgroundColor:"#543090",flexDirection:'row',borderRadius:50,minWidth:140,paddingLeft:20,paddingRight:20,paddingHorizontal:15}]}>
                                        
                                    <View style={{marginRight:8,marginTop:0}}>
                                    <Image source={require('../assets/giftbox.png')} style={{width:20,height:20}} resizeMode='contain'/>
                                    </View>

                                    <Text style={[style.invoiceText,{fontSize:14,color:"#ffffff",marginTop:3,fontFamily:"Poppins-SemiBold"}]}>
                                    140 Points
                                    </Text>  

                                    <View style={{marginLeft:8,marginTop:0}}>
                                    <Image source={require('../assets/right-arroww.png')} style={{width:10,height:10}} resizeMode='contain'/>
                                    </View>
                                
                                    </View>
                                </TouchableOpacity>

                            
                            </View>

                    </View>

                    {/** Menu Items */}
                 <View style={[style.centerContent,{marginTop:40}]}>
                
                        <TouchableOpacity onPress={()=>{navigation.navigate("History")}} style={style.centerContent}>
                            <Image source={require("../assets/history.png")} 
                                    style={{width:45,height:45}}
                                    /> 
                            <Text style={[style.text,{marginTop:5}]}>Mon historique</Text>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={()=>{navigation.navigate("Wallet")}} style={[style.centerContent,{marginTop:20}]}>
                            <Image source={require("../assets/wallet.png")} 
                                    style={{width:45,height:45}}
                                    /> 
                            <Text style={[style.text,{marginTop:5}]}>Mon Wallet</Text>
                        </TouchableOpacity>


                        <TouchableOpacity onPress={()=>{navigation.navigate("Favorite")}} style={[style.centerContent,{marginTop:20}]}>
                            <Image source={require("../assets/heart.png")} 
                                    style={{width:45,height:45}}
                                    /> 
                            <Text style={[style.text,{marginTop:5}]}>Favoris</Text>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={()=>{navigation.navigate("Support")}} style={[style.centerContent,{marginTop:20}]}>
                            <Image source={require("../assets/call-center.png")} 
                                    style={{width:45,height:45}}
                                    /> 
                            <Text style={[style.text,{marginTop:20}]}>Assistance</Text>
                        </TouchableOpacity>

                       
                 
                 <View style={{flexDirection:'row',marginTop:40}}>

                        <View style={[style.centerContent,{marginHorizontal:40}]}>
                            <Text style={[style.textEndRide,{fontSize:12,marginTop:0}]}>
                                Partager
                            </Text>
                            <Text style={[style.textEndRide,{fontSize:12,marginTop:0}]}>
                                l'application
                            </Text>
                           
                            <Image source={require("../assets/woyologov.png")} 
                                    style={{width:80,height:20}} 
                                    resizeMode='contain'
                                    /> 
                           
                        </View>

                        {/*<View>
                        <TouchableOpacity onPress={()=>{navigation.navigate('Login')}}>
                                    
                                    <View style={[style.centerContent,{marginTop:5}]}>

                                    <Text style={[style.text,{fontSize:11,textDecorationLine:'underline',marginTop:3,color:"#d51d1d"}]}>
                                     Deconnexion
                                    </Text>  
                                
                                    </View>
                        </TouchableOpacity>
                        </View>*/}


                        <View style={[style.centerContent,{marginHorizontal:40}]}>
                            <Text style={[style.textEndRide,{fontSize:12,marginTop:0,color:"#12ed93"}]}>
                                Devenir
                            </Text>
                            <Text style={[style.textEndRide,{fontSize:12,marginTop:0, color:"#12ed93"}]}>
                                chauffeur
                            </Text>
                           
                            <Image source={require("../assets/woyologog.png")} 
                                    style={{width:80,height:20}} 
                                    resizeMode='contain'
                                    /> 
                           
                        </View>


                   

                     

                 </View>
    
                    
                </View>

                 
                       <View>
                        <TouchableOpacity onPress={()=>{navigation.navigate('Login')}}>
                                    
                                    <View style={[style.centerContent,{marginTop:5}]}>

                                    <Text style={[style.text,{fontSize:11,textDecorationLine:'underline',marginTop:3,color:"#d51d1d"}]}>
                                     Deconnexion
                                    </Text>  
                                
                                    </View>
                        </TouchableOpacity>
                        </View>

                  

        </View>
      
            
          

        </SafeAreaView>
      
    )
}