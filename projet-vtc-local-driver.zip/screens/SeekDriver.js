import {
    SafeAreaView,
    Dimensions,
    ImageBackground
} from 'react-native'
import React, { useState, useEffect } from 'react'
import { useNavigation } from '@react-navigation/native';
import Video from 'react-native-video';



const width = Dimensions.get('screen').width
const height = Dimensions.get('screen').height

export default function SeekDriver() {

    const navigation = useNavigation();

    useEffect(() => {
      setTimeout(() => {
         navigation.navigate("Polyline")
      }, 8000);


  },[])

  return (
    <SafeAreaView style={{flex:1}}>

    {/*<Video source={require("../assets/splash.mp4")}
    style={{flex:1}}
    muted={true}
    repeat={true}
    resizeMode={"cover"}
    rate={1.0}
    ignoreSilentSwitch={"obey"} 
    />*/}

    <ImageBackground source={require('../assets/loading.jpg')} resizeMode='cover' style={{height:height,width:width}}
    />

    </SafeAreaView>
  )
}