import { View, Text,Dimensions,Image,TouchableOpacity,ScrollView,Linking, Platform,ToastAndroid,TextInput } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import BottomComponent from '../navigator/BottomComponent';
//import SendIntentAndroid from 'react-native-send-intent';




const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function Support() {

const navigation = useNavigation();


const makeACall = ()=>{

    if (Platform.OS === 'android') {
        phoneNumber = 'tel:${2720259797}';
      } else {
        phoneNumber = 'telprompt:${2720259797}';
      }
  
      Linking.openURL(phoneNumber);

}


const WhatsApp = () => {
    const whatsappNumber = '2250556618062';
    const url = `https://wa.me/${whatsappNumber}`;
  
   
           Linking.openURL(url).catch((err) =>  // Handle the case where opening WhatsApp is not supported.
          // console.log("Opening WhatsApp is not supported.");
           ToastAndroid.showWithGravityAndOffset(
             'Notre support Whatsapp est indisponible en ce ',
             ToastAndroid.LONG,
             ToastAndroid.BOTTOM,
             25,
             50,
           ));
        
       
         
           }   
      
  
  



    
    return (
        <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
          <ScrollView>
          <View style={[style.centerContent]}>
                      <View>
                            {/*Header*/}
                            <View style={[{flexDirection:"row", backgroundColor:"#543090",width:width,height:85}]}>

                                <View>
                                <TouchableOpacity onPress={()=>{navigation.navigate("Home")}}>
                                    <View style={[ { paddingLeft:10,paddingRight:10,marginTop:30}]}>
                                   
                                        <Image
                                            source={require("../assets/left-arroww.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:24,height:24}]} 
                                            resizeMode='contain' />

                                    </View>
                                 </TouchableOpacity>
                                </View>

                                <View style={{margin:20}}>
                                    <Image
                                    source={require("../assets/w1.png")}
                                    //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                    style={{width:50,height:50}} 
                                    resizeMode='contain' /> 
                                </View>

                                <View>
                                   <Text style={[style.textHeaderGiftPoints,{fontSize:18}]}>Besoin d'aide ?</Text> 
                                </View>
                              
                            
                            </View>

                            <View>
                                {/*Options support*/}
                                <TouchableOpacity onPress={()=>{WhatsApp()}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1, fontSize:14, marginTop:35 }]}>Ecrire sur Whatsapp</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>

                                 <TouchableOpacity onPress={()=>{ navigation.navigate("Chat") }}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1, fontSize:14, marginTop:35 }]}>Chater en direct</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>


                                 <TouchableOpacity onPress={()=>{makeACall()}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1, fontSize:14, marginTop:35 }]}>Appeler le support</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>

                                 {/** Input recherche */}

                                <View style={[style.inputContainer,{height:47,width:width}]}>
                                
                                    <Image source={require("../assets/search.png")} 
                                        style={{width:16,height:16}}
                                        /> 
                            

                                    <TextInput style={style.inputSearch}
                                    placeholder="Rechercher un article" 
                                    placeholderTextColor="gray"/>
                                    
                                </View>

                               

                                {/*Articles rédigés*/}
                                <TouchableOpacity onPress={()=>{navigation.navigate("Article")}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1, fontSize:14, marginTop:35 }]}>Comment commander une course ?</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>

                                <TouchableOpacity onPress={()=>{navigation.navigate("Article")}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1, fontSize:14, marginTop:35 }]}>Comment recharger mon wallet ?</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>

                                 <TouchableOpacity onPress={()=>{navigation.navigate("Article")}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1, fontSize:14, marginTop:35 }]}>Comment devenir chauffeur ?</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>

                                 <TouchableOpacity onPress={()=>{navigation.navigate("Article")}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1, fontSize:14, marginTop:35 }]}>Comment obtenir des points bonus ?</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>

                                 <TouchableOpacity onPress={()=>{navigation.navigate("Article")}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1, fontSize:14, marginTop:35 }]}>Comment réserver un taxi ?</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>

                                 
                                
                            </View>

                         

                    </View>
            </View>
          </ScrollView>
            
              

        </SafeAreaView>
      
    )
}