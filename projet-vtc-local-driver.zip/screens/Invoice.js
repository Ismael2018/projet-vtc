import { View,Dimensions,Image,Text,TouchableOpacity,TextInput,ToastAndroid,SafeAreaView } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import StarRating from 'react-native-star-rating-widget';


const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function Invoice() {

const navigation = useNavigation();
const [driverName,setdriverName] = useState("Jean Martial Doua"); //Nom du chauffeur
const [rideAmount,setrideAmount] = useState(2785);
const [rating, setRating] = useState(0);

        return(
            <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>

                <View style={[style.centerContent]}>

                    <View style={style.swipedCursor}></View>
                    
                    {/**Photo */}
                    <View>
                        <Image source={{uri:"https://solitude.link/stage/woyo/wp-content/uploads/2023/02/intro1.jpg"}} 
                            style={[style.invoicePhoto]}
                            resizeMode='cover' /> 
                    </View>

                    {/**Date */}
                    <View>
                        <Text style={style.invoiceDate}>Jeudi 13 Juillet 2023</Text>
                    </View>

                     {/**Text Information */}
                     <View style={style.centerContent}>
                        <Text style={[style.invoiceText]}>Merci de noter votre voyage avec </Text>
                        <Text style={[style.invoiceText,{marginTop:0}]}>{driverName} </Text>

                         {/**Rating */}
                         <StarRating
                            rating={rating}
                            onChange={setRating}
                            style={style.rating}
                            color="#12ed93"
                        />

                          {/**Text Information */}
                        <Text style={[style.invoiceText,{fontSize:23,color:"#000000",marginTop:35}]}>Total à payer : </Text>
                        <Text style={[style.invoiceText,{fontSize:35,color:"#000000",marginTop:15,fontFamily:"Poppins-Bold"}]}>{rideAmount} CFA</Text>
                    </View>

                    {/**Button */}
                    <View>
                        <TouchableOpacity onPress={()=>{navigation.navigate("PayRideWallet")}} style={[style.secondButtonMiddleContent,{width:width-150} ]}>
                            <Text style={style.textButtonCmdCourse}>Terminer</Text> 
                        </TouchableOpacity>
                    </View>
                    
                </View>

            </SafeAreaView>
        )

}