import { View, Text,Dimensions,Image,TouchableOpacity } from 'react-native'
import React, { useEffect, useState, useRef, useContext  } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import MapboxGL, {
  MapView,
  UserLocation,
  Camera,
  Images
} from '@rnmapbox/maps';
import Token from '../mapBoxToken';
import Geolocation from 'react-native-geolocation-service';
import { GeneralContext } from '../context';
import { request, PERMISSIONS } from 'react-native-permissions';
import Modal from 'react-native-modal';
import navigationIcon from '../assets/navigation.png';
import {AnimatedCircularProgress} from 'react-native-circular-progress';


const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

MapboxGL.setWellKnownTileServer('Mapbox');
MapboxGL.setAccessToken(Token);

export default function Home() {

 
  useEffect(() => {
    requestLocationPermission();
    showHideModalForOrder()

}, []);

const navigation = useNavigation();
const mapRef = useRef(null);
const [userLatitude, setuserLatitude] = useState('');
const [userLongitude, setuserLongitude] = useState('');
const { UserLatitudeContext,updateUserLatitudeContext } = useContext(GeneralContext);
const { UserLongitudeContext,updateUserLongitudeContext } = useContext(GeneralContext);
const camera = useRef(null);
const [visible, setVisible] = useState(false);
const [isModalVisible, setModalVisible] = useState(false);
const [isModalForError, setisModalForError] = useState(false);
const [isModalForOrderVisible, setisModalForOrderVisible] = useState(false);
const [zoomLevel, setZoomLevel] = useState(17.5); 
const [progressInterval, setProgress] = useState(0);


const toggleModal = () => {
  setModalVisible(!isModalVisible);
};

const showHideModal = ()=> {
  setVisible(!visible);
}

const showHideModalForOrder = () => {
  setProgress(0); // Réinitialisez la progression lorsque le modal s'ouvre

  setisModalForOrderVisible(!isModalForOrderVisible);


  //Le chauffeur a un délai de 30 secondes pour accepter la course
  if (isModalForOrderVisible) {
    clearInterval(progressInterval); // Arrêtez l'intervalle si le modal se ferme
  } else {
    const progressInterval = setInterval(() => {
      setProgress((prevProgress) => {
        const newProgress = prevProgress + 1;
        if (newProgress >= 100) {
          clearInterval(progressInterval);
          setisModalForOrderVisible(false);
        }
        return newProgress;
      });
    }, 300);
  }
};


const showHideModalForError = ()=> {
  setisModalForError(!isModalForError);
}


const requestLocationPermission = async () => {
  try {
    if (Platform.OS === 'android') {
      const granted = await request(PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION);
      if (granted === 'granted') {
        console.log('Autorisation de localisation accordée');
        getUserLocation();
      } else {
        console.log('Autorisation de localisation refusée');
      }
    } else {
      // Pour iOS, la demande d'autorisation est gérée par défaut par le système d'exploitation
      getUserLocation();
    }
  } catch (err) {
    console.warn('Erreur lors de la demande d\'autorisation de localisation :', err);
  }
};


const getUserLocation = () => {

  // Obtenez la position GPS de l'utilisateur
  Geolocation.getCurrentPosition(
   (position) => {
    if(position){
      setuserLatitude(position.coords.latitude)
      setuserLongitude(position.coords.longitude)
      updateUserLatitudeContext(position.coords.latitude)
      updateUserLongitudeContext(position.coords.longitude)
      console.log(position.coords.latitude)
      console.log(position.coords.longitude)
    }
    
   },
   (error) => {
      showHideModalForError()
     console.log('Erreur lors de la récupération de la position GPS :', error);
   },
   { enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
 );
 
}


function cameraMoveTo() {


    if (camera.current) {
      console.log('Calling setCamera with new coordinates:', UserLongitudeContext, UserLatitudeContext);
      camera.current.setCamera({
        centerCoordinate: [UserLongitudeContext, UserLatitudeContext],
      });
    } else {
      console.log('Camera ref is null or undefined.');
    }
  }


  const zoomIn = () => {
    setZoomLevel((prevZoom) => Math.min(prevZoom + 1, 20));
  };
  
  const zoomOut = () => {
    setZoomLevel((prevZoom) => Math.max(prevZoom - 1, 5));
  };
  
  
  


// Si les coordonnées GPS n'ont pas été récupérées, affichez un message de chargement
if (!userLatitude && !userLongitude) {
  return (
     <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
         <View style={[style.centerContent,{flex:1}]}>
                 <Image    source={require("../assets/gif1.gif")}
                                 resizeMode='contain'
                                 style={{ width:90, height:90}} /> 
 
                 <Image    source={require("../assets/woyologov.png")}
                                 resizeMode='contain'
                                 style={{ width:70, height:70, marginTop:-30}} /> 
         </View>
    </SafeAreaView>
  );
 }
 
  
  
    return (
      <SafeAreaView style={{backgroundColor:"#f4f4f4",flex:1}}>
        
            <View style={[style.centerContent]}>
                        <View>
                                {/*Header*/}
                                <View style={[{width:width,height:height}]}>

                                {/**Map */}
                              
                                  <MapboxGL.MapView
                                        style={style.FullMap}
                                        ref={mapRef}>
                                         <MapboxGL.Camera zoomLevel={zoomLevel} 
                                                    centerCoordinate={[UserLongitudeContext,UserLatitudeContext]} 
                                                    ref={camera} />
                                        <MapboxGL.UserLocation
                                          androidRenderMode={'gps'}
                                          showsUserHeadingIndicator={true}
                                          renderMode={'native'}
                                          customMarker={<MapboxGL.Image source={navigationIcon} resizeMode="contain" style={style.tinyIcon} />}
                                          
                                          
                                        />
                                       
                                      </MapboxGL.MapView>
                                 {/**Ajust button */}   
                                 
                                </View>
                        </View>
            </View>

                              {/**Header infos */}
                              <View style={[style.ajustLocationButton,{top:30}]}>
                                <TouchableOpacity onPress={()=>{navigation.navigate("Profil")}} style={{flexDirection:"row",marginLeft:10,minWidth:120,height:66,backgroundColor:"#fff",borderRadius:35,padding:15,paddingRight:25}}>
                                  
                                  <View>
                                    <Image   source={require("../assets/user.png")}
                                                style={{width:36,height:36}} 
                                                resizeMode='contain'/> 
                                  </View>

                                    <View style={{marginLeft:10}}>
                                      <View>
                                          <Text style={[style.textHeaderGiftPoints,{color:"#000",marginTop:0}]}>0 F</Text>
                                      </View>
                                      <View>
                                        <Text style={[style.text,{color:"#e2574c",marginTop:-10}]}>Hors ligne</Text>
                                      </View>
                                  </View>
                                  
                                </TouchableOpacity>      
                              </View>


                                {/**Boutons on the screen */}
                             <Text style={[style.title,{color:"#000",zIndex:2,position:"absolute",right:28,fontSize:27,bottom:300}]}>+</Text>
                              <View style={[style.ajustLocationButton,{bottom:300}]}>
                                    <TouchableOpacity onPress={()=>{zoomIn()}} style={{marginTop:40,marginLeft:10,width:56,height:56,backgroundColor:"#fff",opacity:0.5,borderRadius:30}}>
                                    </TouchableOpacity>
                              </View>


                              <Text style={[style.title,{color:"#000",zIndex:2,position:"absolute",right:30,fontSize:29,bottom:235}]}>-</Text>
                              <View style={[style.ajustLocationButton,{bottom:235}]}>
                              <TouchableOpacity onPress={()=>{zoomOut()}} style={{marginTop:40,marginLeft:10,width:56,height:56,backgroundColor:"#fff",opacity:0.5,borderRadius:30}}>
                                        
                                        </TouchableOpacity>
                                        
                              </View>

                                <View style={[style.ajustLocationButton,{bottom:150}]}>
                                    <TouchableOpacity onPress={()=>{cameraMoveTo()}} style={{marginTop:40,marginLeft:10,opacity:0.7}}>
                                        <Image   source={require("../assets/ajust.png")}
                                            style={{width:56,height:56}} 
                                            resizeMode='contain' /> 
                                    </TouchableOpacity>
                                        
                                </View>


                                <View style={[style.ajustLocationButton,style.centerContent,{bottom:25,left:0,marginRight:0,flexDirection:"row"}]}>
                                    <TouchableOpacity onPress={()=>{showHideModal()}} style={[style.secondButtonMiddleContent,{width:70,height:70,backgroundColor:"#fff",borderStyle:'solid',borderWidth:0,borderColor:"#e2574c",marginHorizontal:10} ]}>
                                    <Image   source={require("../assets/cloud-computing.png")}
                                            style={{width:30,height:30}} 
                                            resizeMode='contain' /> 
                                    </TouchableOpacity>

                                    <TouchableOpacity onPress={()=>{toggleModal()}} style={[style.secondButtonMiddleContent,{width:70,height:70,backgroundColor:"#fff",marginHorizontal:10} ]}>
                                    <Image   source={require("../assets/up-arrow.png")}
                                            style={{width:26,height:26}} 
                                            resizeMode='contain' /> 
                                    </TouchableOpacity>
                                        
                                </View>

                                   {/* Modal du menu*/}
                              <Modal
                                isVisible={isModalVisible}
                                animationIn="slideInUp" // Animation d'apparition
                                animationOut="slideOutDown" // Animation de disparition
                                onBackdropPress={toggleModal} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.modal}
                              >
                                <View style={style.modalContent}>
                                  {/* Contenu du modal */}
                                
                                                        <View style={[style.Modal,{height:height/2}]}>


                                                            <TouchableOpacity style={style.btnCloseModal} onPress={()=>{toggleModal()}}>
                                                                <Image source={require("../assets/close.png")} 
                                                                        style={[style.tinyIcon]}
                                                                        resizeMode='contain' /> 
                                                            </TouchableOpacity>

                             <View style={[{marginTop:-20}]}>             
                                                                    {/*Options support*/}
                                <TouchableOpacity onPress={()=>{toggleModal();navigation.navigate("Profil")}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1,paddingLeft:20, marginTop:35 }]}>Profil</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>

                                 <TouchableOpacity onPress={()=>{navigation.navigate("Gains")}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1,paddingLeft:20, marginTop:35 }]}>Gains</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>


                                 <TouchableOpacity onPress={()=>{toggleModal(); navigation.navigate("Wallet")}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1,paddingLeft:20, marginTop:35 }]}>Wallet</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>

                                 {/*<TouchableOpacity onPress={()=>{}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1,paddingLeft:20, marginTop:35 }]}>Performances</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                    </TouchableOpacity>*/}

                                 <TouchableOpacity onPress={()=>{toggleModal(); navigation.navigate("Support")}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1,paddingLeft:20, marginTop:35 }]}>Support</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>

                                 <TouchableOpacity onPress={()=>{toggleModal(); navigation.navigate("CGU")}}>
                                    <View style={[ { flexDirection: 'row',paddingLeft:10,paddingRight:10}]}>
                                    
                                        <Text style={[style.title, {flex: 1,paddingLeft:20, marginTop:35 }]}>Conditions générales</Text>
                                        <Text style={[style.title, { textAlign: 'right',marginTop:40 }]}>
                                        <Image
                                            source={require("../assets/right-arrown.png")}
                                            //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                            style={[style.tinyIcon,{width:13,height:13}]} 
                                            resizeMode='contain' />

                                        </Text>
                                    </View>
                                 </TouchableOpacity>
                                                        <View>
                              
                            </View>
                          </View>
                         </View>
                        </View>
                             </Modal>

                               {/**Modal if user profile is not verified */}
                              <Modal isVisible={visible}
                                animationIn="fadeIn" // Animation d'apparition
                                animationOut="fadeOut" // Animation de disparition
                                onBackdropPress={showHideModal} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.centerModal}>
                        
                         <View style={[style.centerContent]}>
                       

                        <View style={[style.Modal,{height:height/3, width:width-30,bottom:0,left:0,right:0}]}>

                            <TouchableOpacity style={style.btnCloseModal} onPress={()=>{showHideModal()}}>
                                <Image source={require("../assets/close.png")} 
                                        style={[style.tinyIcon]}
                                        resizeMode='contain' /> 
                            </TouchableOpacity>

                          <View style={[style.centerContent,{marginTop:-20}]}>   

                          <Image source={require("../assets/woyologov.png")} 
                                        style={{width:100,height:38}}
                                        resizeMode='cover' /> 

                              <Text style={style.text}>Vous devez vous inscrire avant de recevoir des commandes</Text>

                            {/**Boutons */}

                            <View style={[style.centerContent,{marginTop:10}]}>

                                <TouchableOpacity onPress={()=>{showHideModal();navigation.navigate("SignUp")}} style={[style.purpleButton,{width:150,height:65,marginTop:18,marginHorizontal:5,padding:15} ]}>
                                <Text style={[style.textButtonCmdCourse,{marginTop:-3,fontSize:12,textAlign:'center'}]}> S'inscrire </Text> 
                                </TouchableOpacity>
                            </View>
                    
                          </View>

                        </View>


                         </View>

                            </Modal>

                             {/**Modal for Error */}
                             <Modal isVisible={isModalForError}
                                animationIn="fadeIn" // Animation d'apparition
                                animationOut="fadeOut" // Animation de disparition
                                onBackdropPress={showHideModalForError} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.centerModal}>
                        
                         <View style={[style.centerContent]}>
                       

                        <View style={[style.Modal,{height:height/3, width:width-30,bottom:0,left:0,right:0}]}>

                            <TouchableOpacity style={style.btnCloseModal} onPress={()=>{showHideModalForError()}}>
                                <Image source={require("../assets/close.png")} 
                                        style={[style.tinyIcon]}
                                        resizeMode='contain' /> 
                            </TouchableOpacity>

                          <View style={[style.centerContent,{marginTop:-20}]}>   

                          <Image source={require("../assets/woyologov.png")} 
                                        style={{width:100,height:38}}
                                        resizeMode='cover' /> 

                              <Text style={style.text}>Impossible de récupérer votre localisation. Veuillez vérifier votre connexion internet puis réessayez.</Text>

                            {/**Boutons */}

                            <View style={[style.centerContent,{marginTop:10}]}>

                                <TouchableOpacity onPress={()=>{showHideModalForError()}} style={[style.purpleButton,{width:90,height:55,marginTop:18,marginHorizontal:5,padding:15} ]}>
                                <Text style={[style.textButtonCmdCourse,{marginTop:-3,fontSize:12,textAlign:'center'}]}> Ok </Text> 
                                </TouchableOpacity>
                            </View>
                    
                          </View>

                        </View>


                         </View>

                            </Modal>


                               {/** Modal for get ordered rides */}   
                            <Modal   isVisible={isModalForOrderVisible}
                                animationIn="slideInUp" // Animation d'apparition
                                animationOut="slideOutDown" // Animation de disparition
                                onBackdropPress={showHideModalForOrder} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.modal}>
                                      
                                  <View style={style.modalContent}>
                                  

                                    <View style={[style.Modal,{height:height/2.1}]}>

                                    <View style={{flexDirection:"row"}}>
                                      <View style={{flex:1}}>
                                      <TouchableOpacity style={style.btnCloseModal} onPress={()=>{showHideModalForOrder()}}>
                                              <Image source={require("../assets/close.png")} 
                                                    style={[style.tinyIcon]}
                                                    resizeMode='contain' /> 
                                          </TouchableOpacity>

                                      </View>

                                      <View style={{alignItems:'flex-end',margin:20}}>
                                      <AnimatedCircularProgress
                                        size={40}
                                        width={9}
                                        fill={progressInterval}
                                        tintColor="#12ed93"
                                        onAnimationComplete={() => console.log('onAnimationComplete')}
                                        backgroundColor="#3d5875" />
                                      </View>
                                    </View>
                                          

                                      <View style={[style.centerContent,{marginTop:-20}]}>             

                                    
                                    {/**Détails course */}

                                    <View>
                                                <View style={[style.centerContent]}>

                                                <Text style={[style.textHeaderGiftPoints, {fontSize:25,color:"#000",marginTop: 10}]}>800 m - 7 min</Text>
                                                <Text style={[style.text, {marginTop: 0}]}>Nouvelle commande</Text>
                                            
                                                </View>

                                                {/**Trajet */}
                                                <View style={{flexDirection:'row', marginTop:20}}>
                                                <Image source={require('../assets/pin.png')} style={{width:20,height:20}} resizeMode='contain'/>
                                                <Text style={[style.text, {marginTop:0,marginLeft:0}]}>Départ : Rue S22, Abidjan, Marcory</Text>
                                                </View>

                                                <View style={{flexDirection:'row', marginTop:20}}>
                                                <Image source={require('../assets/pin.png')} style={{width:20,height:20}} resizeMode='contain'/>
                                                <Text style={[style.text, {marginTop:0,marginLeft:0}]}>Arrivée : Avenue Noguès, Abidjan, Plateau</Text>
                                                </View>

                                              
                                                
                                                {/**Tarif Course*/}
                                                <View style={{flexDirection:'row'}}>
                                                <Text style={[style.textEndRide, {flex:1,marginTop:30,marginLeft:10}]}>PRIX</Text>
                                                <Text style={[style.textEndRide, {marginTop:30,marginRight:20}]}>3750 CFA</Text>
                                                </View>

                                                {/**Accepter */}

                                                <TouchableOpacity onPress={()=>{navigation.navigate("NavigationView")}} style={[style.secondButtonMiddleContent,{width:width-50,marginTop:15} ]}>
                                                  <Text style={style.textButtonCmdCourse}>Accepter la course</Text> 
                                                </TouchableOpacity>

                                                

                                    </View>

                                          
                                    
                                      </View>

                                    </View>


                                  </View>

                            </Modal>
   
       </SafeAreaView>
      
    )
}