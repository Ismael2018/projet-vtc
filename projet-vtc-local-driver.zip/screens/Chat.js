import { View, Text,Dimensions,Image,TouchableOpacity,ScrollView,Linking, Platform,ToastAndroid,TextInput,SafeAreaView } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';



const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function Chat() {

const navigation = useNavigation();

    
    return (
        <View style={{backgroundColor:"#fff",flex:1}}>
          <ScrollView>

           
          <View style={[style.centerContent]}>
                      <View>
                            {/*Header*/}
                            <View style={[{flexDirection:"row", backgroundColor:"#543090",width:width,height:85}]}>

                              <TouchableOpacity onPress={()=>{navigation.navigate("Support")}}>
                                    <View style={{margin:20, marginTop:30}}>
                                    <Image
                                        source={require("../assets/left-arroww.png")}
                                        //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                        style={{width:20,height:20}} 
                                        resizeMode='contain' /> 

                                    </View>
                                </TouchableOpacity>

                                <View style={{margin:20,marginLeft:2}}>

                                    <Image
                                    source={require("../assets/w2.png")}
                                    //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                    style={{width:50,height:50}} 
                                    resizeMode='contain' /> 
                                </View>

                                <View>
                                   <Text style={[style.textHeaderGiftPoints,{fontSize:18}]}>WILLY DE WOYO</Text> 
                                </View>
                              
                            
                            </View>

                           

                         

                    </View>
            </View>

            
          </ScrollView>


              {/*Footer*/}
              <View style={[style.centerContent,{flexDirection:'row',bottom:40}]}>

                {/** Chat Input */}
                <View style={[style.inputContainer,{width:width-80}]}>
    
                        <TextInput style={[style.inputStyle,{fontFamily:"Poppins-Regular",width:width-150,fontSize:13}]}  
                        placeholder="Ecrivez votre message ici..." placeholderTextColor="gray" />
                        
                </View>

                 <View>
                    <TouchableOpacity style={{marginTop:40,marginLeft:10}}>
                        <Image   source={require("../assets/send.png")}
                            style={{width:46,height:46}} 
                            resizeMode='contain' /> 
                    </TouchableOpacity>
                 
                        
                </View>

             </View>
            

        </View>
      
    )
}