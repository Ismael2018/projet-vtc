import {
    SafeAreaView,
    Dimensions,
    ImageBackground
} from 'react-native'
import React, { useState, useEffect } from 'react'
import { useNavigation } from '@react-navigation/native';
import Video from 'react-native-video';



const width = Dimensions.get('screen').width
const height = Dimensions.get('screen').height

export default function Splash() {

    const navigation = useNavigation();

    useEffect(() => {
      setTimeout(() => {
          navigation.navigate("Home")
      }, 4000);


  },[])

  return (
    <SafeAreaView style={{flex:1}}>

    <Video source={require("../assets/splash.mp4")}
    style={{flex:1}}
    muted={true}
    repeat={false}
    resizeMode={"cover"}
    rate={1.0}
    ignoreSilentSwitch={"obey"} 
    />

    </SafeAreaView>
  )
}