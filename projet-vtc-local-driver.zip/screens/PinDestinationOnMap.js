import { View, Text,Dimensions,Image,TouchableOpacity,ToastAndroid,PermissionsAndroid, Platform,TextInput } from 'react-native'
import React, { useEffect, useState, useRef, useContext  } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import { animateCamera } from '@rnmapbox/maps'
import Mapbox, { Camera, UserLocation  } from '@rnmapbox/maps';
import Token from '../mapBoxToken';
import Geolocation from 'react-native-geolocation-service';
import { GeneralContext } from '../context';



const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

Mapbox.setWellKnownTileServer('Mapbox');
Mapbox.setAccessToken(Token);

export default function PinDestinationOnMap() {

const navigation = useNavigation();
const [favourite, setfavourite] = useState(false);
const [userLocation, setUserLocation] = useState(null);
const mapRef = useRef(null);
const { UserLatitudeContext,updateUserLatitudeContext } = useContext(GeneralContext);
const { UserLongitudeContext,updateUserLongitudeContext } = useContext(GeneralContext);
const camera = useRef(null);



function cameraMoveTo() {


    if (camera.current) {
      console.log('Calling setCamera with new coordinates:', UserLongitudeContext, UserLatitudeContext);
      camera.current.setCamera({
        centerCoordinate: [UserLongitudeContext, UserLatitudeContext],
      });
    } else {
      console.log('Camera ref is null or undefined.');
    }
  }



  
  
    return (
      <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
        
            <View style={[style.centerContent]}>
                        <View>
                                {/*Header*/}
                                <View style={[{width:width,height:height}]}>

                                     <View style={[style.headerBtn,style.centerContent,{zIndex:2,backgroundColor:"#543090",position:'absolute',width:width}]}>

                                                {/**Bouton close */}
                                                <View style={{marginTop:5,marginLeft:0}}>
                                                    <TouchableOpacity style={{width:35}} onPress={()=>{navigation.navigate("OrderRide")}}>
                                                        <Image source={require('../assets/left-arroww.png')} style={{width:18,height:18, marginHorizontal:0}} resizeMode='contain'/>
                                                    </TouchableOpacity>
                                                </View>


                                                <View style={{marginBottom:15}}>
                                                        <Text style={[style.transaction,{color:"#fff",fontSize:18,marginHorizontal:60}]}>Votre destination</Text>   
                                                </View>

                                     </View>

                                {/**Map */}        
                                <Mapbox.MapView style={style.FullMap} ref={mapRef}>

                                    <Mapbox.Camera zoomLevel={15} 
                                                    centerCoordinate={[UserLongitudeContext,UserLatitudeContext]} 
                                                    ref={camera}
                                    />
                                        <Mapbox.PointAnnotation id="point" coordinate={[UserLongitudeContext, UserLatitudeContext]} 
                                        // Utilisez le nom de l'image prédéfinie dans les ressources de Mapbox ou l'URI local de votre image
                                        // Par exemple, pour une image prédéfinie : iconImage="marker-15"
                                        // Pour une image locale : iconImage={require('../assets/pin.png')}
                                        iconImage={require('../assets/pin_tiny.png')}
                                        >
                                    <Mapbox.Callout title="Votre emplacement" />
                                    </Mapbox.PointAnnotation>

                                </Mapbox.MapView>
                                 {/**Ajust button */}   
                                 
                                </View>
                        </View>
            </View>

                              <View style={[style.ajustLocationButton,{bottom:120}]}>
                                    <TouchableOpacity onPress={()=>{cameraMoveTo()}} style={{marginTop:40,marginLeft:10}}>
                                        <Image   source={require("../assets/ajust.png")}
                                            style={{width:46,height:46}} 
                                            resizeMode='contain' /> 
                                    </TouchableOpacity>
                                        
                                </View>


                                <View style={[style.ajustLocationButton,{bottom:25}]}>
                                    <TouchableOpacity onPress={()=>{navigation.navigate("ConfirmRide")}} style={[style.secondButtonMiddleContent,{width:width-20} ]}>
                                        <Text style={style.textButtonCmdCourse}>Confirmer</Text> 
                                    </TouchableOpacity>
                                        
                                </View>
   
       </SafeAreaView>
      
    )
}