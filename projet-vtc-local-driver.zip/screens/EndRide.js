import { View,Dimensions,Image,Text,TouchableOpacity,SafeAreaView, ImageBackground } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';



const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function EndRide() {

const navigation = useNavigation();

        return(
            <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
                <ImageBackground source={require('../assets/EndRide.jpg')} resizeMode='cover' style={{width:width,height:height}}>
                   
                    
                    {/**Bouton close */}
                    <View style={{marginTop:30,marginLeft:20}}>
                    <TouchableOpacity onPress={()=>{navigation.navigate("Home")}}>
                        <Image source={require('../assets/close.png')} style={style.tinyIcon} />
                    </TouchableOpacity>
                    </View>
                    

                    {/**Text */}
                    <View style={[style.centerContent,{marginTop:30}]}>
                        <Text style={style.textEndRide}>Merci d'avoir</Text>
                        <Text style={[style.textEndRide,{marginTop:0}]}>contribué à faire</Text>
                        <Text style={[style.textEndRide,{marginTop:0}]}>bouger ta ville</Text>
                       <View style={{flexDirection:'row',display:'flex'}}> 
                       <Text style={[style.textEndRide,{marginTop:0}]}>avec </Text> 
                       <Text style={{margin:0, marginTop:-12}}><Image source={require('../assets/woyologov.png')} style={[{width:80,height:40}]} resizeMode='contain' /></Text></View> 
                    </View>


                    {/**Button */}
                   <View style={[style.centerContent,{marginTop:230}]}> 
                    <TouchableOpacity onPress={()=>{navigation.navigate("Home")}} style={[style.secondButtonMiddleContent,{width:width-200,backgroundColor:"#12ed93"} ]}>
                        <Text style={[style.textButtonCmdCourse]}>Revenir à l'accueil</Text> 
                    </TouchableOpacity>
                   </View>

                </ImageBackground>
            </SafeAreaView>
        )

}