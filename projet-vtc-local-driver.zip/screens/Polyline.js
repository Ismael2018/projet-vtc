import { View, Text,Dimensions,Image,TouchableOpacity,Linking } from 'react-native'
import React, { useState, useRef, useContext, useEffect  } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import Mapbox, { Camera, UserLocation  } from '@rnmapbox/maps';
import Token from '../mapBoxToken';
import { GeneralContext } from '../context';
import StarRating from 'react-native-star-rating-widget';
import Modal from 'react-native-modal';
import Menu from './Menu';


const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

Mapbox.setWellKnownTileServer('Mapbox');
Mapbox.setAccessToken(Token);

export default function Polyline() {

const navigation = useNavigation();
const [favourite, setfavourite] = useState(false);
const [userLocation, setUserLocation] = useState(null);
const mapRef = useRef(null);
const { UserLatitudeContext,updateUserLatitudeContext } = useContext(GeneralContext);
const { UserLongitudeContext,updateUserLongitudeContext } = useContext(GeneralContext);
const camera = useRef(null);
const [visibleMenu, setVisibleMenu] = useState(false); //To make Modal visible or not

/*useEffect(() => {
    Mapbox.setStyleURL('mapbox://styles/mapbox/streets-v11'); 
  }, []);*/

const [carCoordinates, setCarCoordinates] = useState([UserLongitudeContext+0.0010, UserLatitudeContext+0.0008]);

const showHideModalMenu = ()=> {
  setVisibleMenu(!visibleMenu);
}


const makeACall = (driverPhoneNumber)=>{

    if (Platform.OS === 'android') {
        phoneNumber = `tel:${driverPhoneNumber}`;
      } else {
        phoneNumber = `telprompt:${driverPhoneNumber}`;
      }
  
      Linking.openURL(phoneNumber);

}

function cameraMoveTo() {


    if (camera.current) {
      console.log('Calling setCamera with new coordinates:', UserLongitudeContext, UserLatitudeContext);
      camera.current.setCamera({
        centerCoordinate: [UserLongitudeContext, UserLatitudeContext],
      });
    } else {
      console.log('Camera ref is null or undefined.');
    }
  }

  return (
    <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
        
    <View style={[style.centerContent]}>
                <View>
                        {/*Header*/}
                        <View style={[{width:width,height:height/3}]}>

                             <View style={[style.headerBtn,style.centerContent,{zIndex:2,position:'absolute',width:width}]}>

                                        {/**Bouton close */}
                                        <View style={{marginTop:30,marginLeft:0}}>
                                            <TouchableOpacity style={{width:35}} onPress={()=>{navigation.navigate("Home")}}>
                                                <Image source={require('../assets/closev.png')} style={{width:30,height:30, marginHorizontal:0}} resizeMode='contain'/>
                                            </TouchableOpacity>
                                        </View>


                                        <View>
                                                <Text style={[style.transaction,{color:"#000000",fontSize:18,marginHorizontal:width/3,marginTop:33}]}></Text>   
                                        </View>

                                        <View style={{marginTop:30,marginLeft:20}}>
                                        <TouchableOpacity onPress={()=>{showHideModalMenu()}}>
                                            <Image source={require('../assets/menuv.png')} style={{width:30,height:30, marginHorizontal:0}} resizeMode='contain'/>
                                        </TouchableOpacity>
                                        </View>  

                             </View>

                   

                        {/**Map */}        
                    <Mapbox.MapView style={[style.HalfMap,{height:height/3}]} ref={mapRef} scrollEnabled={true}>

                          <Mapbox.Camera zoomLevel={15} 
                                            centerCoordinate={[UserLongitudeContext,UserLatitudeContext]} 
                                            ref={camera}
                            /> 
                                <Mapbox.PointAnnotation id="point" coordinate={[UserLongitudeContext, UserLatitudeContext]} 
                                iconImage={require('../assets/pin_tiny.png')}
                                >
                                    <Mapbox.Callout title="Vous êtes ici" />
                               
                                </Mapbox.PointAnnotation>

                               <Mapbox.PointAnnotation
                                    id="car"
                                    coordinate={carCoordinates}
                                    iconImage={require('../assets/berlinerouge.png')}
                                    >
                                    <Mapbox.Callout title="Vehicle location" />
                                </Mapbox.PointAnnotation>
            
                    </Mapbox.MapView>
                         {/**Ajust button */} 
                         <View style={style.ajustLocationButton}>
                            <TouchableOpacity onPress={()=>{cameraMoveTo()}} style={{marginTop:40,marginLeft:10}}>
                                <Image   source={require("../assets/ajust.png")}
                                    style={{width:46,height:46}} 
                                    resizeMode='contain' /> 
                            </TouchableOpacity>
                                
                        </View> 

                        </View>

                        <View>

                      
                              <View style={{marginLeft:10}}>
                                <Text style={[style.invoiceText,{fontSize:15,color:"#000", marginLeft:7}]}>Ismaël,</Text>
                                <Text style={[style.invoiceText,{fontSize:15,color:"#000", marginLeft:3,marginTop:-5}]}> Votre chauffeur est arrivé </Text>
                             </View>
                              {/**Infos chauffeur */}
                              <View style={{flexDirection:'row'}}>
                                <View style={{marginLeft:20}}>
                                    <Image source={{uri:"https://solitude.link/stage/woyo/wp-content/uploads/2023/02/intro1.jpg"}} 
                                        style={[style.invoicePhoto,{width:45,height:45}]}
                                        resizeMode='cover' /> 
                                </View>

                                <View>

                                <View style={{marginTop:27}}>
                                <Text style={[style.title,{marginTop:0,fontSize:12,marginLeft:10}]}>Konan Jean-Luc</Text>
                                </View>

                                <View>
                                     {/**Rating */}
                                    <StarRating
                                        rating={5}
                                        starSize={13}
                                        onChange={()=>{}}
                                        style={[style.rating,{marginLeft:5,marginTop:0}]}
                                        color="#12ed93"
                                    />
                                </View>

                                <View style={{marginTop:10}}>
                                <Text style={[style.text,{marginTop:-5,fontSize:10,marginLeft:12}]}>ECONOMIQUE</Text>
                                </View>

                                </View>
                            </View>

                            {/**Boutons */}

                            <View style={[style.centerContent,{flexDirection:'row'}]}>

                                <TouchableOpacity onPress={()=>{}} style={[style.greenButton,{width:width/2.3,height:50,marginTop:18,marginHorizontal:5} ]}>
                                <Text style={[style.textHeaderGiftPoints,{marginTop:5,fontSize:14}]}>Chat </Text> 
                                </TouchableOpacity>

                                <TouchableOpacity onPress={()=>{makeACall("0749793919")}} style={[style.greenButton,{width:width/2.3,height:50,marginTop:18,marginHorizontal:5} ]}>
                                <Text style={[style.textHeaderGiftPoints,{marginTop:5,fontSize:14}]}>Appeler </Text> 
                                </TouchableOpacity>
                            </View>

                            <View style={style.lineSeparator}></View>

                            <View style={{flexDirection:'row',marginLeft:10}}>

                            <View style={{flex:1,flexDirection:'row'}}>
                                <View style={{marginLeft:20,marginTop:-8}}>
                                    <Image source={require("../assets/KIA.png")} 
                                        style={[style.invoicePhoto,{width:30,height:30}]}
                                        resizeMode='contain' /> 
                                </View>

                                <View >
                                <Text style={[style.text,{fontSize:13,color:"#000", marginLeft:20,marginTop:28}]}>KIA Pegas - noire </Text>
                                </View>

                            </View>
                              {/**Immatriculation Vehicule*/}
                              <View style={[style.centerContent,{marginRight:10,marginTop:18,height:35,backgroundColor:"#543090",borderRadius:25,minWidth:80,paddingLeft:10,paddingRight:10,paddingHorizontal:15}]}>


                                        <Text style={[style.invoiceText,{fontSize:10,color:"#ffffff",marginTop:3,fontFamily:"Poppins-SemiBold"}]}>
                                        WWCI000001
                                        </Text>  

                                    </View>
                                
                             </View>

                            <View style={style.lineSeparator}></View>
                            
                            <View style={{flexDirection:'row'}}>
                              <View style={{flex:1, marginLeft:10}}>
                                <Text style={[style.invoiceText,{fontSize:15,color:"#000", marginLeft:7}]}>Détails de la course </Text>
                             </View>
                             
                             {/**Plus d'options = Programmer un trajet + Commander une course pour quelqu'un*/}
                            <TouchableOpacity>
                              <View style={{marginRight:10,flexDirection:'row'}}>
                                    <View> 
                                        <Image source={require("../assets/closev.png")}
                                        style={{width:17,height:17,marginTop:29}} 
                                        resizeMode='contain' /> 
                                    </View>

                                    <View style={{marginHorizontal:5}}>
                                    <Text style={[style.invoiceText,{fontSize:9,color:"#000"}]}> Annuler</Text>
                                    <Text style={[style.invoiceText,{fontSize:9,color:"#000",marginTop:-5.5,marginLeft:2}]}>la course</Text>
                                    </View>
                                 </View>
                              </TouchableOpacity> 
                            </View>

                        {/** Détails */}
                        <View style={[style.centerContent,{marginTop:35}]}>
                           
                           {/*Pickup & Drop Location*/}
                            <View>

                                     <View style={[style.centerContent, { flexDirection: 'row',width:width-40}]}>
                                        <Text style={[style.title, {fontSize:13,flex: 1,marginTop: -8}]}>Bridge Bank.Plateau Rue du commerce</Text>
                                    
                                        
                                        <View style={[style.transaction,{textAlign: 'right',marginTop:-8,marginHorizontal:5,flexDirection:'row'}]}>
                                        
                                        {/** <TouchableOpacity onPress={()=>{navigation.navigate("SearchPickUp")}}>
                                         <Image source={require('../assets/right-arrown.png')} style={{width:18,height:18}} resizeMode='contain'/>
                                        </TouchableOpacity> */}
                                          
                                        </View>
                                        </View>

                                        <Text style={[style.text, {marginTop: 0}]}>Abidjan 24 CI, Rue F16</Text>


                                        <View style={[style.centerContent, { flexDirection: 'row',width:width-40,marginTop:30}]}>
                                        <Text style={[style.title, {fontSize:13,flex: 1,marginTop: -8}]}>Aéroport Félix Houphouet B.</Text>
                                    
                                        {/**Bouton close */}
                                        <View style={[style.transaction,{textAlign: 'right',marginTop:-8,marginHorizontal:5}]}>

                                             <View style={[style.transaction,{textAlign: 'right',marginTop:-8,marginHorizontal:5}]}>

                                             <TouchableOpacity onPress={()=>{}}>
                                                <Image source={require('../assets/right-arrown.png')} style={{width:18,height:18}} resizeMode='contain'/>
                                            </TouchableOpacity>
                                             </View>
                                         
                                        </View>
                                        </View>

                                        <Text style={[style.text, {marginTop: 0}]}>Abidjan 07 CI, Rue G47</Text>

                            </View>
                           
                        </View>
                       
                            
                           

                        </View>

                      

                </View>
                <Modal isVisible={visibleMenu}
                                animationIn="slideInRight" // Animation d'apparition
                                animationOut="slideOutRight" // Animation de disparition
                                onBackdropPress={showHideModalMenu} // Pour fermer le modal en cliquant en dehors de celui-ci
                                backdropTransitionOutTiming={0} // Temps de transition pour fermer le modal
                                style={style.menuModal}>
                        
                         <View style={[style.centerContent]}>
                       

                        <View style={[{height:height, width:width-50}]}>
                            
                            <Menu/>
                          
                        </View>


                         </View>

                </Modal>
    </View>

</SafeAreaView>
  )
}