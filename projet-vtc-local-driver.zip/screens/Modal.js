import { View,Dimensions,Image,Modal,Pressable,Text } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';



const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function ModalView(props) {

const navigation = useNavigation();
const [modalVisible,setModalVisible]= useState(false);
const [modalText,setmodalText]= useState("");

if(props.isVisible && props.text){
    setModalVisible(props.isVisible)
    setmodalText(props.text)
}
 
    
    return (
            <View style={[style.centerContent]}>
             <Modal
                animationType="fade"
                transparent={true}
                visible={modalVisible}
                onRequestClose={() => {
                setModalVisible(!modalVisible);
                }}>
                    <Pressable
                    onPress={() => setModalVisible(!modalVisible)}>
                     <View style={style.header}>
                    <Image style={style.close}
                        source={require('../assets/close.png')} /> 
                    </View>
                    </Pressable>

                    <Text style={style.textModal}>{modalText}</Text>
                
                </Modal>
             </View>
      
    )
}