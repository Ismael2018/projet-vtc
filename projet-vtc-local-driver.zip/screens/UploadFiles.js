import { View,Dimensions,Image,Text,TouchableOpacity,TextInput,ToastAndroid,SafeAreaView, ScrollView } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import ImageCropPicker from 'react-native-image-crop-picker';

const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function UploadFiles() {

const navigation = useNavigation();
const [driverPhoto, setdriverPhoto] = useState(null); //Photo chauffeur
const [driverLicence, setdriverLicence] = useState(null); // Permis de conduire
const [idCard, setidCard] = useState(null); // Carte d'identité
const [proofOfResidence, setproofOfResidence] = useState(null); //certificat de residence
const [vehicleCard, setvehicleCard] = useState(null); // carte grise
const [vehicleInsurance, setvehicleInsurance] = useState(null); //Assurance du vehicule
const [frontVehiclePhoto, setfrontVehiclePhoto] = useState(null); // Photo de l'avant du véhicule
const [backVehiclePhoto, setbackVehiclePhoto] = useState(null); // Photo de l'arrière du véhicule


const takePhoto = (arg) => {
    ImageCropPicker.openCamera({
      width: 300,
      height: 400,
      cropping: true,
      includeBase64: true,
    }).then((response) => {
      if (!response.cancelled) {
        if(arg=="DP"){
            setdriverPhoto(`data:image/png;base64, ${response.data}`);
        }
        else if(arg=="DL"){
            setdriverLicence(`data:image/png;base64, ${response.data}`);
        }
        else if(arg=="IC"){
            setidCard(`data:image/png;base64, ${response.data}`);
        }
        else if(arg=="PR"){
            setproofOfResidence(`data:image/png;base64, ${response.data}`);
        }
        else if(arg=="VC"){
            setvehicleCard(`data:image/png;base64, ${response.data}`);
        }
        else if(arg=="VI"){
            setvehicleInsurance(`data:image/png;base64, ${response.data}`);
        }
        else if(arg=="FVP"){
            setfrontVehiclePhoto(`data:image/png;base64, ${response.data}`);
        }
        else if(arg=="BVP"){
            setbackVehiclePhoto(`data:image/png;base64, ${response.data}`);
        }

        
      }
    }).catch((error) => {
      console.log('Erreur lors de la sélection de l\'image : ', error);
    });
  };


const sendFiles = ()=>{
    ToastAndroid.showWithGravityAndOffset(
        'Nos serveurs sont indisponibles en ce moment, veuillez réessayer plus tard',
        ToastAndroid.LONG,
        ToastAndroid.BOTTOM,
        25,
        50,
      );
}
    
    return (
        <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
            <ScrollView>

                    <View style={{flexDirection:"row"}}>

                    <TouchableOpacity onPress={()=>{navigation.navigate("SignUp")}}>
                                <View style={{marginTop:20,marginLeft:10}}>
                                    <Image
                                    source={require("../assets/leftav.png")}
                                    //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                    style={{width:25,height:25}} 
                                    resizeMode='contain' /> 
                                </View>
                            </TouchableOpacity>


                    <Text style={[style.textPurpleBold,{color:"#000",fontSize:20, marginTop:20, marginLeft:20}]}>Vos documents</Text>
                    </View>
                        

                            

            <View style={[style.centerContent,{marginTop:0}]}>
                
         

                <View style={{flexDirection:'row',marginTop:20}}>
                    <View style={[style.centerContent,{marginHorizontal:15}]}>
                    <TouchableOpacity  onPress={()=>{takePhoto("DP")}}> 
                       {driverPhoto && <Image source={{ uri: driverPhoto }} style={{width:100,height:100,borderRadius:10}} resizeMode='contain'/>}
                       {!driverPhoto && <Image source={require('../assets/apphoto.png')} style={{width:100,height:100}} resizeMode='contain'/>}  
                      </TouchableOpacity>
                      <Text style={[style.text,{fontSize:10,marginTop:5}]}>Votre photo</Text>
                    </View>
                    <View style={[style.centerContent,{marginHorizontal:15}]}>
                    <TouchableOpacity  onPress={()=>{takePhoto("DL")}}> 
                       {driverLicence && <Image source={{ uri: driverLicence }} style={{width:100,height:100,borderRadius:10}} resizeMode='contain'/>}
                       {!driverLicence && <Image source={require('../assets/apphoto.png')} style={{width:100,height:100}} resizeMode='contain'/>}  
                      </TouchableOpacity>
                      <Text style={[style.text,{fontSize:10,marginTop:5}]}>Permis de conduire</Text>
                    </View>
                   
                </View>

                <View style={{flexDirection:'row',marginTop:30}}>
                <View style={[style.centerContent,{marginHorizontal:15}]}>
                    <TouchableOpacity  onPress={()=>{takePhoto("IC")}}> 
                       {idCard && <Image source={{ uri: idCard }} style={{width:100,height:100,borderRadius:10}} resizeMode='contain'/>}
                       {!idCard && <Image source={require('../assets/apphoto.png')} style={{width:100,height:100}} resizeMode='contain'/>}  
                      </TouchableOpacity>
                      <Text style={[style.text,{fontSize:10,marginTop:5}]}>Carte d'idendité</Text>
                    </View>
                    
                    <View style={[style.centerContent,{marginHorizontal:15}]}>
                    <TouchableOpacity  onPress={()=>{takePhoto("PR")}}> 
                       {proofOfResidence && <Image source={{ uri: proofOfResidence }} style={{width:100,height:100,borderRadius:10}} resizeMode='contain'/>}
                       {!proofOfResidence && <Image source={require('../assets/apphoto.png')} style={{width:100,height:100}} resizeMode='contain'/>}  
                      </TouchableOpacity>
                      <Text style={[style.text,{fontSize:10,marginTop:5}]}>certificat de résidence</Text>
                    </View>
                </View>

                <View style={{flexDirection:'row',marginTop:30}}>
                
                    <View style={[style.centerContent,{marginHorizontal:15}]}>
                    <TouchableOpacity  onPress={()=>{takePhoto("VC")}}> 
                       {vehicleCard && <Image source={{ uri: vehicleCard }} style={{width:100,height:100,borderRadius:10}} resizeMode='contain'/>}
                       {!vehicleCard && <Image source={require('../assets/apphoto.png')} style={{width:100,height:100}} resizeMode='contain'/>}  
                      </TouchableOpacity>
                      <Text style={[style.text,{fontSize:10,marginTop:5}]}>Carte grise</Text>
                    </View>
                    <View style={[style.centerContent,{marginHorizontal:15}]}>
                    <TouchableOpacity  onPress={()=>{takePhoto("VI")}}> 
                       {vehicleInsurance && <Image source={{ uri: vehicleInsurance }} style={{width:100,height:100,borderRadius:10}} resizeMode='contain'/>}
                       {!vehicleInsurance && <Image source={require('../assets/apphoto.png')} style={{width:100,height:100}} resizeMode='contain'/>}  
                      </TouchableOpacity>
                      <Text style={[style.text,{fontSize:10,marginTop:5}]}>Assurance du véhicule</Text>
                    </View>
                </View>

                <View style={{flexDirection:'row',marginTop:30}}>
                    <View style={[style.centerContent,{marginHorizontal:15}]}>
                    <TouchableOpacity  onPress={()=>{takePhoto("FVP")}}> 
                       {frontVehiclePhoto && <Image source={{ uri: frontVehiclePhoto }} style={{width:100,height:100,borderRadius:10}} resizeMode='contain'/>}
                       {!frontVehiclePhoto && <Image source={require('../assets/apphoto.png')} style={{width:100,height:100}} resizeMode='contain'/>}  
                      </TouchableOpacity>
                      <Text style={[style.text,{fontSize:10,marginTop:5}]}>Avant du véhicule</Text>
                    </View>
                    <View style={[style.centerContent,{marginHorizontal:15}]}>
                    <TouchableOpacity  onPress={()=>{takePhoto("BVP")}}> 
                       {backVehiclePhoto && <Image source={{ uri: backVehiclePhoto }} style={{width:100,height:100,borderRadius:10}} resizeMode='contain'/>}
                       {!backVehiclePhoto && <Image source={require('../assets/apphoto.png')} style={{width:100,height:100}} resizeMode='contain'/>}  
                      </TouchableOpacity>
                      <Text style={[style.text,{fontSize:10,marginTop:5}]}>Arrière du véhicule</Text>
                    </View>
                
                </View>
               
                 <TouchableOpacity onPress={()=>{sendFiles();navigation.navigate("Home")}} style={[style.secondButtonMiddleContent,{width:width-20} ]}>
                    <Text style={style.textButtonCmdCourse}>Terminer</Text> 
                </TouchableOpacity>
             </View>

        </ScrollView>
        </SafeAreaView>
      
    )
}