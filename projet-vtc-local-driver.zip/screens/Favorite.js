import { View, Text,Dimensions,Image,TouchableOpacity,ScrollView,TextInput } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import BottomComponent from '../navigator/BottomComponent';
//import BottomComponent from '../navigator/BottomComponent';



const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function Favorite() {

const navigation = useNavigation();



    
    return (
        <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
          <ScrollView>
          <View style={[style.centerContent]}>
                      <View>
                            {/*Header*/}
                            <View style={[style.headerBtn,style.centerContent]}>
                              {/**Bouton close */}
                              <View style={{marginTop:30,marginLeft:0}}>
                                <TouchableOpacity style={{width:35}} onPress={()=>{navigation.navigate("Home")}}>
                                    <Image source={require('../assets/closev.png')} style={{width:30,height:30, marginHorizontal:0}} resizeMode='contain'/>
                                </TouchableOpacity>
                                </View>


                                <View >
                                        <Text style={[style.transaction,{color:"#000000",fontSize:18,marginHorizontal:width/5,marginTop:33}]}>Mes favoris</Text>   
                                </View>

                                <View style={{marginTop:30,marginLeft:20}}>
                               
                                </View>  
                            
                            </View>

                    </View>

                    {/** Input recherche */}
                 <View style={[style.inputContainer,{height:43,width:width-30}]}>
                
                    <Image source={require("../assets/search.png")} 
                        style={{width:16,height:16}}
                        /> 
                 
    
                        <TextInput style={style.inputSearch}
                        placeholder="Entrez une destination" placeholderTextColor="gray"/>
                        
                     </View>

                     <View style={[{height:45}]}>
                           
                    </View>
                           
                {/*Saved Places*/}
                    <View>
                            
                                <View style={[style.centerContent, { flexDirection: 'row',width:width-40}]}>
                                <Text style={[style.title, {fontSize:15,flex: 1,marginTop: -8}]}>Aéroport Félix Houphouet B.</Text>
                               
                                {/**Bouton close */}
                               <View style={[style.transaction,{textAlign: 'right',marginTop:-8,marginHorizontal:5}]}>
                               
                                        <Image source={require('../assets/close.png')} style={style.tinyIcon} resizeMode='contain'/>
                                </View>
                                </View>

                                <Text style={[style.text, {marginTop: 0}]}>Abidjan 07 CI, Rue G47</Text>


                    </View>

                  

        </View>
          </ScrollView>
            
              <BottomComponent />

        </SafeAreaView>
      
    )
}