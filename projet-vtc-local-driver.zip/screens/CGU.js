import { View, Text,Dimensions,Image,TouchableOpacity,ScrollView,Linking, Platform,ToastAndroid,TextInput } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';




const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function CGU() {

const navigation = useNavigation();



    
    return (
        <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
          <ScrollView>
          <View style={[style.centerContent]}>
            {/*Header*/}
                      <View>
                            <TouchableOpacity onPress={()=>{navigation.navigate("Home")}}>
                                <View style={{marginTop:20,marginLeft:-20}}>
                                    <Image
                                    source={require("../assets/leftav.png")}
                                    //source={{uri:"https://i.pinimg.com/564x/d0/7b/51/d07b51aa1fbd871620c804e602ac2a29.jpg"}}
                                    style={{width:25,height:25}} 
                                    resizeMode='contain' /> 
                                </View>
                            </TouchableOpacity>

                                <View>
                                   <Text style={[style.textEndRide,{color:"#000"}]}>Conditions générales d'utilisation</Text> 
                                </View>
                    </View>

                    <View>
                        <Text style={[style.text,{width:width-30}]}> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                        </Text>

                        <Text style={[style.text,{width:width-30}]}> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                        </Text>

                        

                    </View>


            </View>
          </ScrollView>
            

        </SafeAreaView>
      
    )
}