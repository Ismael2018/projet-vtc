import { View, Text,Dimensions,Image,TouchableOpacity,ScrollView,Modal,TextInput,RefreshControl,ToastAndroid } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';
import { SafeAreaView } from 'react-navigation';
import BottomComponent from '../navigator/BottomComponent';

const height = Dimensions.get('screen').height;
const width = Dimensions.get('screen').width;

export default GiftPoints = () => {

    const navigation = useNavigation();
    const [refreshing, setRefreshing] = useState(false);


const onRefresh = () => {
    // Mettez à jour l'état de rafraîchissement
    setRefreshing(true);
  
    // Effectuez les actions de rafraîchissement (ex. : récupération de nouvelles données)

    ToastAndroid.showWithGravityAndOffset(
      'Mise à jour effectuée',
      ToastAndroid.LONG,
      ToastAndroid.BOTTOM,
      25,
      50,
    );
    // Mettez à jour l'état de rafraîchissement après avoir terminé les actions de rafraîchissement
    setRefreshing(false);
  };

    return(

    <SafeAreaView style={{backgroundColor:"#ffffff",flex:1}}>
        <ScrollView refreshControl={
            <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            />
        } > 
            <View style={[style.centerContent]}>
                        <View>
                                {/*Header*/}
                                <View style={[style.boxRoundedHeader,{backgroundColor:"#543090",height:height/2.85}]}>

                                 {/**Bouton close */}
                                <View style={{marginTop:35}}>
                                {/*<TouchableOpacity style={{width:35}} onPress={()=>{navigation.navigate("Wallet")}}>
                                    <Image source={require('../assets/close.png')} style={style.tinyIcon} />
                                </TouchableOpacity>*/}
                                </View>

                                <View style={style.centerContent}>
                                   
                                    {/**Nombre de poitns */}
                                    <View style={[style.centerContent,{marginTop:25,height:65,backgroundColor:"#12ed93",flexDirection:'row',borderRadius:50,minWidth:160,paddingLeft:20,paddingRight:20,paddingHorizontal:15}]}>
                                        
                                        <View style={{marginRight:8,marginTop:0}}>
                                        <Image source={require('../assets/giftbox.png')} style={{width:25,height:25}} resizeMode='contain'/>
                                        </View>

                                        <Text style={[style.invoiceText,{fontSize:18,color:"#ffffff",marginTop:3,fontFamily:"Poppins-SemiBold"}]}>
                                        1250 points
                                        </Text>  

                                    </View>


                                    <View style={[style.centerContent]}>
                                            {/*Gift categories*/}
                                            <View style={{flexDirection:'row',display:'flex',marginTop:38}}> 
                                                    <Text style={[style.textHeaderGiftPoints,{marginTop:0}]}>Vos points fidélité </Text> 
                                                    <Text style={{margin:5, marginTop:-15 }}><Image source={require('../assets/woyologo.png')} style={[{width:70,height:35}]} resizeMode='contain' /></Text>
                                            </View> 
                                        </View>
                                  
                                </View>

                                </View>

                            <View style={[style.main,{marginLeft:60}]}>
                                {/*Gift categories*/}

                                {/**Woyo category */}
                             <View>
                              <View style={{flexDirection:'row',display:'flex',marginTop:15}}> 
                                        <Text style={[style.textWalletHeader,{marginTop:0, color:"#543090"}]}>Mon </Text> 
                                        <Text style={{margin:5, marginLeft:0, marginTop:-20 }}><Image source={require('../assets/woyologov.png')} style={[{width:70,height:35}]} resizeMode='contain' /></Text>
                                </View>
                                <Text style={[style.title,{marginTop:0}]}>De 0 à 500 points</Text>

                                <Text style={[style.text,{marginTop:25}]}>° Avantages promotionnels</Text>
                                <Text style={[style.text,{marginTop:8}]}>° Avantages saisonniers (Anniversaires, célébrations ...)</Text>
                             </View>
                                
                                {/**Woyo Bronz */}
                             <View>
                                <View style={{flexDirection:'row',display:'flex',marginTop:30}}> 
                                        <Text style={[style.textWalletHeader,{marginTop:0, color:"#543090"}]}>Mon </Text> 
                                        <Text style={{margin:5, marginLeft:0, marginTop:-20 }}><Image source={require('../assets/woyologov.png')} style={[{width:70,height:35}]} resizeMode='contain' /></Text>
                                        <Text style={[style.textWalletHeader,{marginTop:0 ,color:"#543090"}]}>Bronz </Text> 
                                </View>
                                <Text style={[style.title,{marginTop:0}]}>De 501 à 1000 points</Text>
                                
                                <Text style={[style.text,{marginTop:25}]}>° Avantages promotionnels</Text>
                                <Text style={[style.text,{marginTop:8}]}>° Avantages saisonniers (Anniversaires, célébrations ...)</Text>
                                <Text style={[style.text,{marginTop:8}]}>° Primeurs sur les lancements (Livraison, shop ...)</Text>
                            </View>


                            {/**Woyo Silver */}
                            <View>
                                <View style={{flexDirection:'row',display:'flex',marginTop:30}}> 
                                        <Text style={[style.textWalletHeader,{marginTop:0, color:"#543090"}]}>Mon </Text> 
                                        <Text style={{margin:5, marginLeft:0, marginTop:-20 }}><Image source={require('../assets/woyologov.png')} style={[{width:70,height:35}]} resizeMode='contain' /></Text>
                                        <Text style={[style.textWalletHeader,{marginTop:0 ,color:"#543090"}]}>Argent </Text> 
                                </View>
                                <Text style={[style.title,{marginTop:0}]}>De 1001 à 2000 points</Text>
                                
                                <Text style={[style.text,{marginTop:25}]}>° Avantages promotionnels et saisonniers</Text> 
                                <Text style={[style.text,{marginTop:8}]}>° Primeurs sur les lancements (Livraison, shop ...)</Text>
                                <Text style={[style.text,{marginTop:8}]}>° Augmentation de la capacité d'emprunt</Text>
                            </View>

                             {/**Woyo Gold */}
                             <View>
                                <View style={{flexDirection:'row',display:'flex',marginTop:30}}> 
                                        <Text style={[style.textWalletHeader,{marginTop:0, color:"#543090"}]}>Mon </Text> 
                                        <Text style={{margin:5, marginLeft:0, marginTop:-20 }}><Image source={require('../assets/woyologov.png')} style={[{width:70,height:35}]} resizeMode='contain' /></Text>
                                        <Text style={[style.textWalletHeader,{marginTop:0 ,color:"#543090"}]}>Or </Text> 
                                </View>
                                <Text style={[style.title,{marginTop:0}]}>De 2001 à 3000 points</Text>
                                
                                <Text style={[style.text,{marginTop:25}]}>° Avantages promotionnels et saisonniers</Text> 
                                <Text style={[style.text,{marginTop:8}]}>° Primeurs sur les lancements (Livraison, shop ...)</Text>
                                <Text style={[style.text,{marginTop:8, marginRight:20}]}>° Augmentation de la capacité d'emprunt et conversion des points obtenus pour payer vos courses</Text>
                            </View>


                            {/**Woyo Platinium */}
                            <View>
                                <View style={{flexDirection:'row',display:'flex',marginTop:30}}> 
                                        <Text style={[style.textWalletHeader,{marginTop:0, color:"#543090"}]}>Mon </Text> 
                                        <Text style={{margin:5, marginLeft:0, marginTop:-20 }}><Image source={require('../assets/woyologov.png')} style={[{width:70,height:35}]} resizeMode='contain' /></Text>
                                        <Text style={[style.textWalletHeader,{marginTop:0 ,color:"#543090"}]}>Platinium </Text> 
                                </View>
                                <Text style={[style.title,{marginTop:0}]}>+ de 3001 points</Text>
                                
                                <Text style={[style.text,{marginTop:25}]}>° Avantages promotionnels et saisonniers</Text> 
                                <Text style={[style.text,{marginTop:8}]}>° Primeurs sur les lancements (Livraison, shop ...)</Text>
                                <Text style={[style.text,{marginTop:8, marginRight:20}]}>° Augmentation de la capacité d'emprunt et conversion des points obtenus pour payer vos courses</Text>
                                <Text style={[style.text,{marginTop:8, marginRight:20}]}>° Transfert de points et cadeaux WOYO (Agenda, Ticket restau, Cinema...)</Text>
                            </View>
                               

                             </View>

                        </View>
            </View>
         </ScrollView>

        <BottomComponent/>
    </SafeAreaView>

    );
}