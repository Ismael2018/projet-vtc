import { View,Dimensions,Image,Text,TouchableOpacity } from 'react-native';
import React from 'react'
import { useNavigation } from '@react-navigation/native';
import style from '../style/style';



const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width

export default function BottomComponent() {

const navigation = useNavigation();

    return( 
        <View style={{flexDirection:'row'}}>
            <TouchableOpacity onPress={()=>{navigation.navigate("Home")}} style={{justifyContent:'center',alignItems:'center'}}>
                <Image
                source={require("../assets/home.png")}
                style={style.iconFooter} /> 
            <Text style={{fontSize:8,color:"#646263"}}>Accueil</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={()=>{navigation.navigate("Support")}} style={{justifyContent:'center',alignItems:'center'}}>
                <Image
                source={require("../assets/call-center.png")}
                style={style.iconFooter} /> 
            <Text style={{fontSize:8,color:"#646263"}}>Support</Text>
            </TouchableOpacity>


            <TouchableOpacity onPress={()=>{navigation.navigate("Wallet")}} style={{justifyContent:'center',alignItems:'center'}}>
                <Image
                source={require("../assets/wallet.png")}
                style={style.iconFooter} /> 
            <Text style={{fontSize:8,color:"#646263"}}>Wallet</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={()=>{navigation.navigate("History")}} style={{justifyContent:'center',alignItems:'center'}}>
                <Image
                source={require("../assets/history.png")}
                style={style.iconFooter} /> 
            <Text style={{fontSize:8,color:"#646263"}}>Historique</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={()=>{navigation.navigate("Profil")}} style={{justifyContent:'center',alignItems:'center'}}>
                <Image
                source={require("../assets/account.png")}
                style={style.iconFooter} /> 
            <Text style={{fontSize:8,color:"#646263"}}>Profil</Text>
            </TouchableOpacity>
        </View>
            )

}


/**  */