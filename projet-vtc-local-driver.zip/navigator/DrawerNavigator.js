// DrawerNavigator.tsx

import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import StackNavigator from './StackNavigator'; // Remplacez le chemin par le chemin correct vers le fichier StackNavigator
//import MenuScreen from '../screens/Menu'; // Remplacez le chemin par le chemin correct vers votre composant de menu

const Drawer = createDrawerNavigator();

const DrawerNavigator = () => {
  return (
    <Drawer.Navigator>
      <Drawer.Screen name="Main" component={StackNavigator} />
      {/* Ajoutez d'autres écrans du menu ici si nécessaire */}
      {/* <Drawer.Screen name="Menu" component={MenuScreen} /> */}
    </Drawer.Navigator>
  );
};

export default DrawerNavigator;
