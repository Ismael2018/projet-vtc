import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import Splash from '../screens/SplashScreen';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Login from '../screens/Login';
import SignUp from '../screens/SignUp';
import OTP from '../screens/OTP';
import Invoice from '../screens/Invoice';
import EndRide from '../screens/EndRide';
import Wallet from '../screens/Wallet';
import Support from '../screens/Support';
import History from '../screens/History';
import Profil from '../screens/Profil';
import RechargeWallet from '../screens/RechargeWallet';
import PayRideWallet from '../screens/PayRideWallet';
import Favorite from '../screens/Favorite';
import Menu from '../screens/Menu';
import GiftPoints from '../screens/GiftPoints';
import Article from '../screens/Article';
import Chat from '../screens/Chat';
import OrderRide from '../screens/OrderRide';
import SearchDestination from '../screens/SearchDestination';
import ConfirmRide from '../screens/ConfirmRide';
import SearchPickUp from '../screens/SearchPickUp';
import PinPickUpOnMap from '../screens/PinPickUpOnMap';
import SelectVehicleCategory from '../screens/SelectVehicleCategory';
import SeekDriver from '../screens/SeekDriver';
import Polyline from '../screens/Polyline';
import ScheduleRide from '../screens/ScheduleRide';
import Home from '../screens/Home';
import CGU from '../screens/CGU';
import Withdrawal from '../screens/Withdrawal';
import Gains from '../screens/Gains';
import UploadFiles from '../screens/UploadFiles';
import { NavigationView } from '../screens/NavigationView';
//import { Colors } from '../theme/color';
//import BottomComponent from './BottomComponent';




const Stack = createNativeStackNavigator();
//const Drawer = createDrawerNavigator();

export default function StackNavigator() {
  
  


    return (

            <NavigationContainer>
                <Stack.Navigator 
                    screenOptions={{ headerShown: false }} 
                    initialRouteName="Splash"
                >
                  
                    <Stack.Screen
                        name="Splash"
                        component={Splash}
                        options={{ headerShown:false }}
                        />
                          
                   
                    <Stack.Screen
                        name="Home"
                        component={Home} 
                        options={{ headerShown:false }}
                        />
                    <Stack.Screen
                        name="Login"
                        component={Login} 
                        options={{ headerShown:false }}
                        />

                     <Stack.Screen
                        name="SignUp"
                        component={SignUp} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="OTP"
                        component={OTP} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="Invoice"
                        component={Invoice} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="EndRide"
                        component={EndRide} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="Wallet"
                        component={Wallet} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="Support"
                        component={Support} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="History"
                        component={History} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="Profil"
                        component={Profil} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="RechargeWallet"
                        component={RechargeWallet} 
                        options={{ headerShown:false }}
                        />

                     <Stack.Screen
                        name="Withdrawal"
                        component={Withdrawal} 
                        options={{ headerShown:false }}
                        />

                        <Stack.Screen
                        name="Gains"
                        component={Gains} 
                        options={{ headerShown:false }}
                        />

                        <Stack.Screen
                        name="UploadFiles"
                        component={UploadFiles} 
                        options={{ headerShown:false }}
                        />

                        <Stack.Screen
                        name="CGU"
                        component={CGU} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="PayRideWallet"
                        component={PayRideWallet} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="NavigationView"
                        component={NavigationView} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="Favorite"
                        component={Favorite} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="Menu"
                        component={Menu} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="GiftPoints"
                        component={GiftPoints} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="Article"
                        component={Article} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="Chat"
                        component={Chat} 
                        options={{ headerShown:false }}
                        />

                    <Stack.Screen
                        name="OrderRide"
                        component={OrderRide} 
                        options={{ headerShown:false }}
                        />

                    

                        <Stack.Screen
                        name="SearchDestination"
                        component={SearchDestination} 
                        options={{ headerShown:false }}
                        />

                         <Stack.Screen
                        name="ConfirmRide"
                        component={ConfirmRide} 
                        options={{ headerShown:false }}
                        />

                         <Stack.Screen
                        name="SearchPickUp"
                        component={SearchPickUp} 
                        options={{ headerShown:false }}
                        />

                         <Stack.Screen
                        name="PinPickUpOnMap"
                        component={PinPickUpOnMap} 
                        options={{ headerShown:false }}
                        />

                        <Stack.Screen
                        name="SelectVehicleCategory"
                        component={SelectVehicleCategory} 
                        options={{ headerShown:false }}
                        />

                        <Stack.Screen
                        name="SeekDriver"
                        component={SeekDriver} 
                        options={{ headerShown:false }}
                        />

                        <Stack.Screen
                        name="Polyline"
                        component={Polyline} 
                        options={{ headerShown:false }}
                        />

                        <Stack.Screen
                        name="ScheduleRide"
                        component={ScheduleRide} 
                        options={{ headerShown:false }}
                        />

                    
                   
                    
                </Stack.Navigator>
            </NavigationContainer>
  
       
    )
}